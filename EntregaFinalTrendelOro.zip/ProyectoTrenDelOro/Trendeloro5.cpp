//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    LIBRERIAS  --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

#include <iostream>
#include <string>
#include <cctype> // Para minusculas y isdigit
#include <limits> // Para limpiar el buffer
#include <fstream> // Para archivos
#include <cstdlib> // Para atoi (convierte string a int de forma segura para estudiantes)
#include <random> // Para los dados
#include <string> 
#include <ctime>
#include <cstdlib> // Para srand() y rand()

using namespace std;



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    ESTRUCTURAS  --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------
struct listaImplemento {

    int id;
    string nombre;
    string tipoPersonaje;
    int durabilidad;
    int usos_restantes;
    bool disponible = true;
    int turnos_cooldown = 0; 
    int turnos_disponible = 0;
    string descripcion; 

    listaImplemento* sig = NULL;
};

struct listaPolicia {

    int id;
    string nombre;
    string bando="policia";
    string rango;
    int puntosVida = 100;
    int posicionX = 0;
    int posicionY = 0;
    string estado = "Activo";
    bool corrupto = false;
    int id_estacion;
    listaImplemento mochila [3];
    int lingotes=0;

    listaPolicia* sig = NULL;
};


struct listaLadron {

    int id;
    string nombre;
    string bando="ladron";
    string rango;
    int puntosVida = 100;
    int posicionX = 0;
    int posicionY = 0;
    string estado = "Activo";
    int lingotes = 0;
    int maxCargaDeLingotes = 3;
    int id_estacion=1;
    listaImplemento mochila [3];

    listaLadron* sig = NULL;
};




struct listaEstaciones {

    int id;
    string nombreEstacion;
    int lingotes;

    listaEstaciones* sig = NULL;
};



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    FUNCIONES GENERALES  -----------------------------------------
//-----------------------------------------------------------------------------------------------------------

// Funcion para convertir texto a minusculas
string Minusculas(string texto) {

    for (int i = 0; ((i) < (texto.length())); i++) {
        texto[i] = tolower(texto[i]);
    }
    return texto;
}


// Funcion auxiliar simple para sacar numeros de strings como "Uso: 1"
int extraerNumero(string texto) {

    string numeroStr = "";
    bool numeroEncontrado = false;

    // Recorremos el texto buscando digitos
    for (int i = 0; i < texto.length(); i++) {

        if (isdigit(texto[i])) {
            numeroStr += texto[i];
            numeroEncontrado = true;
        } 
        else if (numeroEncontrado) {
            // Si ya encontramos numeros y viene una letra, paramos
            break;
        }
    }
    
    if (numeroStr == "") {
        return 0;
    } 
    else {
        // atoi es seguro: convierte string a int
        return atoi(numeroStr.c_str());
    }
}



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    MANEJO DE ARCHIVOS   -------------------------------------
//-----------------------------------------------------------------------------------------------------------

void cargarMapa(listaEstaciones* &cabeza) {
    ifstream archivo("Mapa.tren");
    if (!archivo.is_open()) return;

    int cantidad;
    string basura;
    archivo >> cantidad; // Lee el número 30 inicial

    for (int i = 0; i < cantidad; i++) {
        listaEstaciones* nuevo = new listaEstaciones();
        archivo >> basura; // Lee "---"
        archivo >> nuevo->id;
        archivo.ignore(); // Limpiar buffer
        getline(archivo, nuevo->nombreEstacion);
        archivo >> basura; // Lee el primer "-"
        archivo >> basura; // Lee el segundo "-" (lingotes si los hay)
        nuevo->lingotes = 0; // Valor por defecto o inicial
        
        nuevo->sig = cabeza;
        cabeza = nuevo;
    }
    archivo.close();
    cout << "- Mapa cargado." << endl;
}

void cargarAccesorios(listaImplemento* &cabeza) {
    ifstream archivo("accesorios.tren");
    if (!archivo.is_open()) return;

    int cantidad;
    string basura;
    archivo >> cantidad;

    for (int i = 0; i < cantidad; i++) {
        listaImplemento* nuevo = new listaImplemento();
        
        archivo >> basura; // Lee "---"
        archivo >> nuevo->id;
        archivo.ignore(); // Limpia el salto de línea tras el ID

        getline(archivo, nuevo->tipoPersonaje); // "Policia" o "Ladron"
        getline(archivo, nuevo->nombre);        // "Patines Electricos"
        getline(archivo, nuevo->descripcion);   // "Funcion: Movilidad/Evasion"

        // LEER USO:
        // Usamos >> para saltar la palabra "Uso:" y capturar el número
        archivo >> basura; // Captura "Uso:"
        archivo >> nuevo->usos_restantes; 
        nuevo->durabilidad = nuevo->usos_restantes; // Inicializamos durabilidad igual a los usos

        // LEER ALCANCE:
        archivo >> basura; // Captura "Alcance:"
        archivo >> basura; // Captura el número del alcance (puedes guardarlo si quieres)

        archivo.ignore(); // Limpia el buffer para la siguiente iteración

        // Insertar en la lista enlazada
        nuevo->sig = cabeza;
        cabeza = nuevo;
    }
    archivo.close();
    cout << "- Implementos cargados correctamente." << endl;
}

void cargarPersonajes(listaPolicia* &cabezaP, listaLadron* &cabezaL) {
    ifstream archivo("personajes.tren");
    if (!archivo.is_open()) return;

    int cantidad;
    string basura, bando, lineaNombre;
    archivo >> cantidad;

    for (int i = 0; i < cantidad; i++) {
        int id;
        archivo >> basura >> id; // Lee "---" e ID
        archivo.ignore(); 
        getline(archivo, bando); // Lee "Policia" o "Ladron"
        getline(archivo, lineaNombre); // Lee "Oficial Roca Tytus"

        // LÓGICA DE DIVISIÓN: Rango vs Nombre
        size_t espacio = lineaNombre.find(' '); 
        string rangoExtraido = "";
        string nombreExtraido = "";

        if (espacio != string::npos) {
            rangoExtraido = lineaNombre.substr(0, espacio); // Primera palabra
            nombreExtraido = lineaNombre.substr(espacio + 1); // El resto
        } else {
            rangoExtraido = "N/A";
            nombreExtraido = lineaNombre;
        }

        if (bando.find("Policia") != string::npos) {
            listaPolicia* p = new listaPolicia();
            p->id = id;
            p->rango = rangoExtraido;
            p->nombre = nombreExtraido;
            archivo >> basura; // Lee el "-"
            p->sig = cabezaP;
            cabezaP = p;
        } else {
            listaLadron* l = new listaLadron();
            l->id = id;
            l->rango = rangoExtraido;
            l->nombre = nombreExtraido;
            archivo >> basura; // Lee el "-"
            l->sig = cabezaL;
            cabezaL = l;
        }
        archivo.ignore(); // Limpiar el salto de línea después del "-"
    }
    archivo.close();
    cout << "- Personajes cargados." << endl;
}

// ----------------------------------------------------------------------------------
// FUNCIONES DE BITACORA (LOG)
// ----------------------------------------------------------------------------------

// Funcion 1: Limpia el archivo al iniciar una nueva partida (Opcional, pero recomendado)
void reiniciarBitacora() {
    ofstream archivo("bitacora.txt"); // Al no usar ios::app, esto borra el contenido anterior
    if (archivo.is_open()) {
        archivo << "=== INICIO DE NUEVA PARTIDA DEL TREN DEL ORO ===" << endl;
        archivo << "------------------------------------------------" << endl;
        archivo.close();
    }
}

// Funcion 2: Registra un evento nuevo al final del archivo sin borrar lo anterior
void registrarBitacora(string evento) {
    // ios::app es la clave: significa "Append" (Anexar al final)
    ofstream archivo("bitacora.txt", ios::app); 
    
    if (archivo.is_open()) {
        // Obtenemos la hora actual para que el registro sea profesional
        time_t now = time(0);
        tm *ltm = localtime(&now);

        // Formato: [HH:MM:SS] Evento
        archivo << "[" << ltm->tm_hour << ":" << ltm->tm_min << ":" << ltm->tm_sec << "] " 
                << evento << endl;
                
        archivo.close();
    }
}


//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    POLICIAS   --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existePolicia(listaPolicia* policia, int idPolicia) {

    listaPolicia *puntero = policia;

    while (puntero != NULL) {

        if (puntero->id == idPolicia) {
            return true;
        }
        puntero = puntero->sig;
    }
    return false;
}


void crearPolicia(listaPolicia*&cabezaPolicia) {

    listaPolicia* nuevo = new listaPolicia;
    int idPolicia;
    bool repetir = true;

    while (repetir) {

        cout << "- Indique el id: " << endl;
        cin >> idPolicia;

        if (existePolicia(cabezaPolicia, idPolicia)) {
            cout << "! Ya existe ese ID." << endl;
        } 
        else {
            repetir = false;
            nuevo->id = idPolicia;
        }
    }

    cout << endl;
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    cout << "- Indique el nombre: " << endl;
    
    string nombre;
    getline(cin, nombre); 
    nuevo->nombre = nombre;
    
    cout << "- Seleccione el rango: " << endl;
    cout << "  1. Inspector Jefe" << endl;
    cout << "  2. Perito Forense" << endl;
    cout << "  3. Oficial de Asalto" << endl;
    cout << "  4. Analista de Datos" << endl;
    cout << "  5. Negociador" << endl;
    
    
    string rango;
    cin >> rango;
    
    if (rango == "1") {
        nuevo->rango = "Inspector Jefe";
    }
    else if (rango == "2") {
        nuevo->rango = "Perito Forense";
    }
    else if (rango == "3") {
        nuevo->rango = "Oficial de Asalto";
    }
    else if (rango == "4") {
        nuevo->rango = "Analista de Datos";
    }
    else if (rango == "5") {
        nuevo->rango = "Negociador";
    }
    else { 
        cout << "! Rango invalido." << endl; 
        delete nuevo; 
        return; 
    }

    nuevo->sig = NULL;

    if (cabezaPolicia == NULL) {
        cabezaPolicia = nuevo;
    }
    else {
        listaPolicia* temp = cabezaPolicia;
        while (temp->sig != NULL) {
            temp = temp->sig;
        }
        temp->sig = nuevo;
    }

    cout << "- Policia creado." << endl;
}


void mostrarPolicias(listaPolicia* policia) {

    if (policia == NULL) { 
        cout << "[ No hay policias ]" << endl; 
        return; 
    }
    
    listaPolicia* mostrar = policia;
    cout << endl << "------ POLICIAS--------" << endl;
    int cont = 0;

    while (mostrar != NULL) {

        cout << "[ID: " << mostrar->id << " | " << mostrar->nombre << " | " << mostrar->rango << "]     ";
        cont++;
        
        if (cont == 3) { 
            cout << endl; 
            cont = 0; 
        }

        mostrar = mostrar->sig;
    }
    cout << endl;
}


void modificarPolicia(listaPolicia*&policia) {

    if (policia == NULL) { 
        cout << "No hay policias." << endl; 
        return; 
    }

    int id;
    cout << "- Ingrese ID a modificar: "; 
    cin >> id;
    
    listaPolicia* buscar = policia;

    while (buscar != NULL && buscar->id != id) {
        buscar = buscar->sig;
    }
    
    if (buscar != NULL) {

        cout << "Que desea modificar?" << endl;
        cout << "1. Nombre" << endl;
        cout << "2. Rango (Bando)" << endl;
        cout << "3. Puntos de Vida y Estado" << endl;
        cout << "4. Posicion" << endl;
        
        int op; 
        cin >> op;

        if (op == 1) {

            cout << "- Nuevo nombre: ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            getline(cin, buscar->nombre);

        }
        else if (op == 2) {

            cout << "- Seleccione nuevo rango: " << endl;
            cout << "1.Inspector / 2.Perito / 3.Asalto / 4.Analista / 5.Negociador / 6.Corrupto: ";
            string rango; 
            cin >> rango;

            // Reiniciamos bando por defecto
            buscar->corrupto = false; 
            buscar->bando = "Policia Honesto";
            
            if (rango == "1") buscar->rango = "Inspector Jefe";
            else if (rango == "2") buscar->rango = "Perito Forense";
            else if (rango == "3") buscar->rango = "Oficial de Asalto";
            else if (rango == "4") buscar->rango = "Analista de Datos";
            else if (rango == "5") buscar->rango = "Negociador";
            else if (rango == "6") { 
                buscar->rango = "Policia"; 
                buscar->corrupto = true; 
                buscar->bando = "Policia";
            }
            else {
                cout << "! Rango invalido. No se cambio." << endl;
            }

        }
        else if (op == 3) {

            cout << "- Nuevos puntos de vida: "; 
            cin >> buscar->puntosVida;
            cout << "- Nuevo estado (Activo/Capturado): "; 
            cin >> buscar->estado;

        }
        else if (op == 4) {

            cout << "- Nueva Posicion X: "; 
            cin >> buscar->posicionX;
            cout << "- Nueva Posicion Y: "; 
            cin >> buscar->posicionY;

        }
        else {
            cout << "! Opcion invalida." << endl;
        }

        cout << "- Modificacion realizada." << endl;

    } 
    else {
        cout << "! ID no encontrado." << endl;
    }
}


void borrarPolicia(listaPolicia*& cabeza) {

    if (cabeza == NULL) { 
        cout << "No hay policias." << endl; 
        return; 
    }

    int id;
    cout << "- ID a borrar: "; 
    cin >> id;
    
    listaPolicia* actual = cabeza;
    listaPolicia* anterior = NULL;
    
    while (actual != NULL && actual->id != id) {
        anterior = actual;
        actual = actual->sig;
    }
    
    if (actual == NULL) { 
        cout << "! ID no encontrado." << endl; 
        return; 
    }
    
    if (anterior == NULL) {
        cabeza = actual->sig;
    }
    else {
        anterior->sig = actual->sig;
    }
    
    delete actual;
    cout << "- Policia eliminado." << endl;
}



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    LADRONES   --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existeLadron(listaLadron* ladron, int id) {

    while (ladron != NULL) {

        if (ladron->id == id) {
            return true;
        }
        ladron = ladron->sig;
    }
    return false;
}


void crearLadron(listaLadron*&cabeza) {

    listaLadron* nuevo = new listaLadron;
    int id;
    bool repetir = true;

    while (repetir) {

        cout << "- Indique el id: "; 
        cin >> id;

        if (existeLadron(cabeza, id)) {
            cout << "! ID ya existe." << endl;
        }
        else { 
            repetir = false; 
            nuevo->id = id; 
        }
    }

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Nombre: "; 
    getline(cin, nuevo->nombre);
    
    cout << "- Rango: " << endl;
    cout << "  1. Cerebro" << endl;
    cout << "  2. Fantasma" << endl;
    cout << "  3. Mulo" << endl;
    cout << "  4. Saboteador" << endl;
    cout << "  5. Divergente" << endl;
    
    string r; 
    cin >> r;

    if (r == "1") nuevo->rango = "Cerebro";
    else if (r == "2") nuevo->rango = "Fantasma";
    else if (r == "3") nuevo->rango = "Mulo";
    else if (r == "4") nuevo->rango = "Saboteador";
    else if (r == "5") nuevo->rango = "Divergente";
    else { 
        cout << "! Invalido." << endl; 
        delete nuevo; 
        return; 
    }

    nuevo->sig = NULL;

    if (cabeza == NULL) {
        cabeza = nuevo;
    }
    else {
        listaLadron* temp = cabeza;
        while (temp->sig != NULL) {
            temp = temp->sig;
        }
        temp->sig = nuevo;
    }

    cout << "- Ladron creado." << endl;
}


void mostrarLadrones(listaLadron* ladron) {

    if (ladron == NULL) { 
        cout << "[ No hay ladrones ]" << endl; 
        return; 
    }

    listaLadron* m = ladron;
    cout << "----- LADRONES -------" << endl;
    int c = 0;

    while (m != NULL) {

        cout << "[ID: " << m->id << " | " << m->nombre << " | " << m->rango << "]  ";
        c++; 
        
        if (c == 3) {
            cout << endl;
            c = 0;
        }
        m = m->sig;
    }
    cout << endl;
}


void modificarLadron(listaLadron*&ladron) {

    if (ladron == NULL) { 
        cout << "No hay ladrones." << endl; 
        return; 
    }

    int id; 
    cout << "- ID a modificar: "; 
    cin >> id;
    
    listaLadron* b = ladron;
    while (b != NULL && b->id != id) {
        b = b->sig;
    }
    
    if (b != NULL) {

        cout << "Que desea modificar?" << endl;
        cout << "1. Nombre" << endl;
        cout << "2. Rango" << endl;
        cout << "3. Vida y Estado" << endl;
        cout << "4. Carga de Lingotes" << endl;
        
        int op; 
        cin >> op;

        if (op == 1) {

            cout << "- Nuevo nombre: "; 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            getline(cin, b->nombre);

        }
        else if (op == 2) {

            cout << "- Rango: 1.Cerebro/2.Fantasma/3.Mulo/4.Saboteador/5.Divergente: ";
            string r; 
            cin >> r;

            if (r == "1") b->rango = "Cerebro";
            else if (r == "2") b->rango = "Fantasma";
            else if (r == "3") b->rango = "Mulo";
            else if (r == "4") b->rango = "Saboteador";
            else if (r == "5") b->rango = "Divergente";
            else cout << "! Invalido." << endl;

        }
        else if (op == 3) {

            cout << "- Nueva Vida: "; cin >> b->puntosVida;
            cout << "- Nuevo Estado: "; cin >> b->estado;

        }
        else if (op == 4) {

            cout << "- Carga Actual: "; cin >> b->lingotes;
            cout << "- Maxima Carga: "; cin >> b->maxCargaDeLingotes;

        }
        else {
            cout << "! Opcion invalida." << endl;
        }

        cout << "- Modificado." << endl;

    } 
    else {
        cout << "! No existe." << endl;
    }
}


void borrarLadron(listaLadron*& cabeza) {

    if (cabeza == NULL) return;

    int id; 
    cout << "- ID a borrar: "; 
    cin >> id;

    listaLadron* act = cabeza;
    listaLadron* ant = NULL;

    while (act != NULL && act->id != id) { 
        ant = act; 
        act = act->sig; 
    }
    
    if (act == NULL) {
        cout << "! No encontrado." << endl;
    }
    else {

        if (ant == NULL) {
            cabeza = act->sig;
        }
        else {
            ant->sig = act->sig;
        }

        delete act;
        cout << "- Eliminado." << endl;
    }
}



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    IMPLEMENTOS   ----------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existeImplemento(listaImplemento* imp, int id) {

    while (imp != NULL) { 

        if (imp->id == id) {
            return true; 
        }
        imp = imp->sig; 
    }
    return false;
}


void crearImplemento(listaImplemento*& cabeza) {

    listaImplemento* nuevo = new listaImplemento;
    int id;

    do {
        cout << "- ID: "; 
        cin >> id;

        if (existeImplemento(cabeza, id)) {
            cout << "! Ya existe." << endl;
        }
        else {
            break;
        }
    } while (true);

    nuevo->id = id;
    
    cout << "- Tipo (1.Policia / 2.Ladron): "; 
    string t; 
    cin >> t;

    if (t == "1") {
        nuevo->tipoPersonaje = "Policia Honesto";
    }
    else {
        nuevo->tipoPersonaje = "Ladron";
    }
    
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Nombre: "; 
    getline(cin, nuevo->nombre);

    cout << "- Durabilidad (numero): "; 
    cin >> nuevo->durabilidad;
    nuevo->usos_restantes = nuevo->durabilidad;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Descripcion: "; 
    getline(cin, nuevo->descripcion);
    
    nuevo->sig = NULL;

    if (cabeza == NULL) {
        cabeza = nuevo;
    }
    else {
        listaImplemento* temp = cabeza;
        while (temp->sig != NULL) {
            temp = temp->sig;
        }
        temp->sig = nuevo;
    }

    cout << "- Implemento creado." << endl;
}


void mostrarImplementos(listaImplemento* imp) {
    cout<<endl;
    cout<<"----- IMPLEMENTOS -------"<<endl;
    if (imp == NULL) {
        cout << "[ Vacio ]" << endl; 
        return;
    }

    listaImplemento* t = imp;

    int c = 0;

    
        
    while (t != NULL) {

        cout << "[ID:" << t->id << " | " << t->nombre << " | " << t->tipoPersonaje << " | Uso:" << t->durabilidad << "]    ";
        t = t->sig;
        c++; 
        
        if (c == 3) {
            cout << endl;
            c = 0;
        }
    }
}


void modificarImplemento(listaImplemento*& imp) {

    if (imp == NULL) return;

    int id; 
    cout << "- ID a modificar: "; 
    cin >> id;

    listaImplemento* b = imp;
    while (b != NULL && b->id != id) {
        b = b->sig;
    }

    if (b != NULL) {

        cout << "1.Nombre 2.Durabilidad 3.Descripcion: ";
        int op; 
        cin >> op;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        
        if (op == 1) { 
            cout << "- Nuevo Nombre: "; 
            getline(cin, b->nombre); 
        }
        else if (op == 2) { 
            cout << "- Nueva Durabilidad: "; 
            cin >> b->durabilidad; 
            b->usos_restantes = b->durabilidad; 
        }
        else if (op == 3) { 
            cout << "- Nueva Descripcion: "; 
            getline(cin, b->descripcion); 
        }
        
        cout << "- Modificado." << endl;

    } 
    else {
        cout << "! No encontrado." << endl;
    }
}


void borrarImplemento(listaImplemento*& cabeza) {

    if (cabeza == NULL) return;

    int id; 
    cout << "- ID borrar: "; 
    cin >> id;

    listaImplemento* act = cabeza; 
    listaImplemento* ant = NULL;

    while (act != NULL && act->id != id){ 
        ant = act; 
        act = act->sig; 
    }

    if (act != NULL) {

        if (ant == NULL) {
            cabeza = act->sig; 
        }
        else {
            ant->sig = act->sig;
        }

        delete act; 
        cout << "- Borrado." << endl;

    } 
    else {
        cout << "! No existe." << endl;
    }
}



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    ESTACIONES    ----------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existeEstacion(listaEstaciones* est, int id) {

    while (est != NULL) { 
        if (est->id == id) return true; 
        est = est->sig; 
    }
    return false;
}


void crearEstacion(listaEstaciones*& cabeza) {

    listaEstaciones* nuevo = new listaEstaciones;
    int id;

    do { 
        cout << "- ID: "; 
        cin >> id; 
        if (!existeEstacion(cabeza, id)) {
            break; 
        }
        cout << "! Existe." << endl; 
    } while (true);

    nuevo->id = id;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "- Nombre: "; 
    getline(cin, nuevo->nombreEstacion);

    
    nuevo->sig = NULL;

    if (cabeza == NULL) {
        cabeza = nuevo;
    }
    else {
        listaEstaciones* t = cabeza;
        while (t->sig != NULL) {
            t = t->sig;
        }
        t->sig = nuevo;
    }

    cout << "- Estacion creada." << endl;
}


void mostrarEstaciones(listaEstaciones* est) {
    cout<<endl;
    cout<<"----- ESTACIONES ------"<<endl;
    if (est == NULL) {
        cout << "[ Vacia ]" << endl; 
        return;
    }

    listaEstaciones* t = est;
    int c = 0;

    while (t != NULL) {

        cout << "[ID:" << t->id << " " << t->nombreEstacion << "]   ";
        c++; 
        
        if (c == 6) {
            cout << endl;
            c = 0;
        }
        t = t->sig;
    }
    cout << endl;
}


void modificarEstacion(listaEstaciones*& est) {

    if (est == NULL) return;

    int id; 
    cout << "- ID a modificar: "; 
    cin >> id;

    listaEstaciones* b = est;
    while (b != NULL && b->id != id) {
        b = b->sig;
    }

    if (b != NULL) {
        
       
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "- Nuevo nombre: "; 
            getline(cin, b->nombreEstacion);
        
       
        cout << "- Modificado." << endl;

    } 
    else {
        cout << "! No encontrado." << endl;
    }
}


void borrarEstacion(listaEstaciones*& cabeza) {

    if (cabeza == NULL) return;

    int id; 
    cout << "- ID borrar: "; 
    cin >> id;

    listaEstaciones* act = cabeza; 
    listaEstaciones* ant = NULL;

    while (act != NULL && act->id != id) { 
        ant = act; 
        act = act->sig; 
    }

    if (act != NULL) {
        if (ant == NULL) cabeza = act->sig; 
        else ant->sig = act->sig;

        delete act; 
        cout << "- Borrada." << endl;
    } 
    else {
        cout << "! No existe." << endl;
    }
}

string obtenerNombreEstacion(int idBusqueda, listaEstaciones* cabezaEstaciones) {
    listaEstaciones* temp = cabezaEstaciones;

    // Recorremos la lista enlazada
    while (temp != NULL) {
        if (temp->id == idBusqueda) {
            // Si encontramos el ID, retornamos el nombre inmediatamente
            return temp->nombreEstacion;
        }
        temp = temp->sig; // Avanzamos al siguiente nodo
    }
}

int contarEstaciones(listaEstaciones* cabezaEstaciones) {
    int contador = 0;
    listaEstaciones* aux = cabezaEstaciones;

    // Recorremos la lista hasta el final
    while (aux != NULL) {
        contador++;
        aux = aux->sig; // Saltamos al siguiente nodo
    }

    return contador;
}


//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    EQUIPOS     ----------------------------------------------
//-----------------------------------------------------------------------------------------------------------


//EQUIPAR LA MOCHILA DE AMBOS BANDOS
void equiparMochila(listaImplemento* implementos, listaPolicia equipo1[4], listaLadron equipo2[4], string bandoPersonaje, int n) {
    
    string nombre;
    

    if (bandoPersonaje=="policia") {
        nombre=equipo1[n].nombre;
    }
    else {
        nombre=equipo2[n].nombre;
    }
    cout << "\n--- SELECCION DE IMPLEMENTOS PARA LA MOCHILA DE " << nombre<<endl;
    
    // Iteramos 3 veces para llenar los 3 slots de la mochila del personaje directamente
    for (int i = 0; i < 3; i++) {

        mostrarImplementos(implementos);
        bool itemValido = false;

        while (!itemValido) {
            int idBuscado;
            cout << "\n Implemento [" << i + 1 << "/3] - Ingrese ID: ";
            cin >> idBuscado;

            listaImplemento* aux = implementos;
            bool encontrado = false;

            while (aux != NULL) {
                if (aux->id == idBuscado) {
                    encontrado = true;
                    if (Minusculas(aux->tipoPersonaje) == Minusculas(bandoPersonaje)) {
                        
                        // CAMBIO CLAVE: Asignamos directamente al slot del personaje
                        if (Minusculas(bandoPersonaje) == "policia") {
                            equipo1[n].mochila[i] = *aux;
                            equipo1[n].mochila[i].sig = NULL;
                        } else {
                            equipo2[n].mochila[i] = *aux;
                            equipo2[n].mochila[i].sig = NULL;
                        }

                        cout << "-> " << aux->nombre << " equipado con éxito." << endl;
                        cout<<endl;
                        itemValido = true;
                    } else {
                        cout << "! Error: Este objeto es para " << aux->tipoPersonaje << "." << endl;
                    }
                    break;
                }
                aux = aux->sig;
            }
            if (!encontrado) cout << "! ID no encontrado." << endl;
        }
    }
}

//ASIGNAR UNA ESTACION ESTRATEGICA A CADA JUGADOR
void asignarEstacion(listaEstaciones* estaciones, listaPolicia equipo1[4], listaLadron equipo2[4], string bandoPersonaje, int n) {
    string nombre;

    if (bandoPersonaje=="policia") {
        nombre=equipo1[n].nombre;
    }
    else {
        nombre=equipo2[n].nombre;
    }
    
    cout << "\n--- SELECCION DE ESTACION INICIAL PARA " << nombre<<endl;
    mostrarEstaciones(estaciones);
    cout<<endl;

    int idEstacion;
    string nombreEstacion;
    bool encontrado = false;

    while (!encontrado) {
        cout << "Ingrese el ID de la estacion de salida: ";
        cin >> idEstacion;

        // Validar que la estación exista en la lista
        if (existeEstacion(estaciones, idEstacion)) {
            encontrado = true;
            
            // Asignar a todos los miembros del equipo
            if (Minusculas(bandoPersonaje) == "policia") {
                
                equipo1[n].id_estacion = idEstacion;
                
            } else {
                equipo2[n].id_estacion = idEstacion;
                
            }
            nombreEstacion = obtenerNombreEstacion(idEstacion,estaciones);
            cout << "-> Estacion " << idEstacion << "("<<nombreEstacion<<") asignada como punto de partida." << endl;
            
        } else {
            cout << "! ID de estacion no valido. Intente de nuevo." << endl;
        }
    }
}

//MOSTRAR LA MOCHILA DE UN JUGADOR
void mostrarMochilaJugador(listaPolicia equipo1[4],listaLadron equipo2[4],string bando, int i) {

        if (bando=="policias") {
            
            cout << " Mochila ->  ";
            for (int j = 0; j < 3; j++) {
                if (equipo1[i].mochila[j].usos_restantes>0) {
                    cout << "[Implemento " << (j + 1) << ": ";
                    cout << equipo1[i].mochila[j].nombre << " (Usos:" << equipo1[i].mochila[j].usos_restantes << ") ]";
                    cout<<"    ";
                    
                }

            }
        }
        else {
            cout << " Mochila ->  ";
            for (int j = 0; j < 3; j++) {
                if (equipo2[i].mochila[j].usos_restantes>0) {
                    cout << "[Implemento " << (j + 1) << ": ";
                    cout << equipo2[i].mochila[j].nombre << " (Usos:" << equipo2[i].mochila[j].usos_restantes << ") ]";
                    cout<<"    ";
                    
                }
            }
        }
            
}

//MOSTRAR LOS EQUIPOS FORMADOS
void mostrarEquipo(listaPolicia equipo1[4],listaLadron equipo2[4],string bando, listaEstaciones* estaciones) {

    if (bando=="policias") {

        cout << "\n============================================================================================" << endl;
        cout << "                               EQUIPO DE POLICIAS (Jugadores Activos)" << endl;
        cout << "============================================================================================" << endl;
        cout<<endl;

        for (int i = 0; i < 4; i++) {
            // Bloque de datos del oficial

            if (equipo1[i].estado=="Activo") {
                int idEstacion = equipo1[i].id_estacion;
                string nombreEstacion = obtenerNombreEstacion(idEstacion,estaciones);
                cout << "* [ OFICIAL " << (i + 1) << ":"
                     << " Nombre: " << equipo1[i].nombre 
                     << " | Rango: " << equipo1[i].rango 
                     << " | Lingotes: " << equipo1[i].lingotes
                     << " | Estacion ID: " << idEstacion << "("<<nombreEstacion<<") ]";
                    cout<<endl;

            }
        }
    }
    else {
         cout << "\n============================================================================================" << endl;
        cout << "                              EQUIPO DE SOMBRAS (Jugadores Activos)" << endl;
        cout << "============================================================================================" << endl;
        cout<<endl;
        for (int i = 0; i < 4; i++) {
            
            // Bloque de datos del ladron
            if (equipo2[i].estado=="Activo") {
                int idEstacion = equipo2[i].id_estacion;
                string nombreEstacion = obtenerNombreEstacion(idEstacion,estaciones);
                cout << "* [ LADRON " << (i + 1) << ":"
                     << " Nombre: " << equipo2[i].nombre 
                     << " | Rango: " << equipo2[i].rango 
                     << " | Lingotes: " << equipo2[i].lingotes
                     << " | Estacion ID: " << idEstacion << "("<<nombreEstacion<<") ]";
                     cout<<endl;;
            }
         
        }
    }
}


//FORMAR EQUIPOS
void formarEquipoPolicias(listaEstaciones* estaciones, listaImplemento* implementos, 
                          listaPolicia* cabeza, listaPolicia equipo1[4], listaLadron equipo2[4]) {
    
    cout << "\n--- FORME SU EQUIPO DE CUATRO POLICIAS ---" << endl;
    
    int seleccionados = 0;
    while (seleccionados < 4) {
        mostrarPolicias(cabeza); 
        int idEleccion;
        cout << "\nIngrese el ID del oficial "<<seleccionados+1<<" que quiere agregar a su equipo: ";
        cin >> idEleccion;

        bool yaElegido = false;
        for (int k = 0; k < seleccionados; k++) {
            if (equipo2[k].id == idEleccion) {
                yaElegido = true;
                break;
            }
        }

        if (yaElegido) {
            cout << "! Este oficial ya ha sido seleccionado para tu equipo. Elige uno diferente." << endl;
            continue; // Salta al inicio del while para pedir otro ID
        }

        listaPolicia* aux = cabeza;
        bool encontrado = false;

        while (aux != NULL) {
            if (aux->id == idEleccion) {
                encontrado = true;
                
                // 1. Guardar el oficial en el índice actual (0, 1, 2 o 3)
                equipo1[seleccionados] = *aux;
                equipo1[seleccionados].sig = NULL; 
                cout<<endl;
                cout << "-> " << aux->nombre << " agregado al equipo." << endl;
                system("pause");
                cout<<endl;
                
                // 2. Equipar y asignar estación usando el índice actual ANTES de incrementar
                cout << "\nEQUIPA A TU PERSONAJE" << endl;
                equiparMochila(implementos, equipo1, equipo2, "policia", seleccionados);
                cout<<endl;
                cout << "-> " << aux->nombre << " equipado correctamente." << endl;
                system("pause");
                cout<<endl;

                cout << "\nASIGNALE UNA ESTACION INICIAL A TU PERSONAJE" << endl;
                asignarEstacion(estaciones, equipo1, equipo2, "policia", seleccionados);
                cout << "\n-> " << equipo1[seleccionados].nombre << " listo para la mision." << endl;
                
                if (seleccionados<3) {
                    cout<<"Proximo integrante..."<<endl;
                }
                system("pause");
                system("cls");


                // 3. Ahora sí, incrementamos para el siguiente oficial
                seleccionados++;
                break;
            }
            aux = aux->sig;
        }

        if (!encontrado) {
            cout << "! ID no encontrado o no disponible. Intente de nuevo." << endl;
        }
    }
    cout << "\n--- EQUIPO POLICIAL COMPLETADO ---\n" << endl;
    mostrarEquipo(equipo1,equipo2,"policias",estaciones);
    system("pause");
    system("cls");
}

void formarEquipoLadrones(listaEstaciones* estaciones, listaImplemento* implementos, listaLadron* cabeza, listaPolicia equipo1[4],listaLadron equipo2[4]) {
    cout << "\n--- FORME SU EQUIPO DE CUATRO LADRONES ---" << endl;
    
    int seleccionados = 0;
    while (seleccionados < 4) {
        mostrarLadrones(cabeza); 
        int idEleccion;
        cout << "Ingrese el ID del ladron " << seleccionados + 1 << " que quiere agregar a su equipo: ";
        cin >> idEleccion;

        bool yaElegido = false;
        for (int k = 0; k < seleccionados; k++) {
            if (equipo2[k].id == idEleccion) {
                yaElegido = true;
                break;
            }
        }

        if (yaElegido) {
            cout << "! Este ladron ya ha sido seleccionado para tu equipo. Elige uno diferente." << endl;
            continue; // Salta al inicio del while para pedir otro ID
        }

        // Buscamos el ladron en la lista original
        listaLadron* aux = cabeza;
        bool encontrado = false;

        while (aux != NULL) {
            if (aux->id == idEleccion) {
                
                equipo2[seleccionados] = *aux;
                equipo2[seleccionados].sig = NULL; // Limpiamos el puntero para evitar errores
                
                cout << "-> " << aux->nombre << " agregado al equipo." << endl;
                encontrado = true;
                
                cout<<endl;
                system("pause");
                cout<<endl;
                cout<<"EQUIPA A TU PERSONAJE"<<endl;
                equiparMochila(implementos,equipo1,equipo2,"ladron",seleccionados);
                cout << "-> " << aux->nombre << " equipado correctamente." << endl;
                system("pause");
                cout<<endl;
                
                cout<<"ASIGNALE UNA ESTACION A TU PERSONAJE"<<endl;
                asignarEstacion(estaciones,equipo1,equipo2,"ladron",seleccionados);
                cout << "-> " << aux->nombre << " listo para la mision." << endl;
                
                
                if (seleccionados<3) {
                    cout<<"Proximo integrante..."<<endl;
                }
                system("pause");
                system("cls");
                
                seleccionados++;
                break;
            }
            aux = aux->sig;
        }

        if (!encontrado) {
            cout << "! ID no encontrado. Intente de nuevo." << endl;
        }
    }
    cout << "--- EQUIPO DE LAS SOMBRAS LISTO---\n" << endl;
    mostrarEquipo(equipo1,equipo2,"ladrones",estaciones);
    system("pause");
    system("cls");
}




//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    PRE-JUEGO   ----------------------------------------------
//-----------------------------------------------------------------------------------------------------------

//FUNCION BOTIN
void distribuirBotin(listaEstaciones* cabeza,int &totalLingotes) {

    bool repetir=true;

    while(repetir==true) {
        cout<<"Ingrese la cantidad de lingotes (botin) a distribuir: ";
        cin>>totalLingotes;

        int contadorEstaciones = 0;
        listaEstaciones* temp = cabeza;
        while (temp != NULL) {
            contadorEstaciones++;
            temp->lingotes = 0; // Limpiamos lingotes previos
            temp = temp->sig;
        }

        if (totalLingotes > (contadorEstaciones * 3)) {
            cout << "! Error: Capacidad insuficiente (" << (contadorEstaciones * 3) 
                << " max). No se pueden repartir " << totalLingotes << " lingotes." << endl;
            
        }
        else {
            repetir=false;
        }
    }
   
    // Inicializar el randomizador dentro de la función usando el tiempo actual
    srand(static_cast<unsigned int>(time(NULL)));
    

    int lingotesRestantes = totalLingotes;

    // 2. Reparto cíclico para asegurar que no sobren lingotes
    while (lingotesRestantes > 0) {
        listaEstaciones* aux = cabeza;
        
        while (aux != NULL && lingotesRestantes > 0) {
            if (aux->lingotes < 3) {
                // Calcula cuánto espacio queda en esta estación (max 3)
                int espacioDisponible = 3 - aux->lingotes;
                
                // Genera un número aleatorio entre 0 y el espacio disponible
                int intentoAsignar = rand() % (espacioDisponible + 1);

                // No podemos asignar más de lo que queda en el pozo total
                if (intentoAsignar > lingotesRestantes) {
                    intentoAsignar = lingotesRestantes;
                }

                aux->lingotes += intentoAsignar;
                lingotesRestantes -= intentoAsignar;
            }
            aux = aux->sig;
        }
        // Si al terminar la lista aún sobran lingotes (por mala suerte del rand), 
        // el while principal volverá a empezar desde la primera estación.
    }

    cout << "-> EXITO: Se han distribuido los " << totalLingotes << " lingotes correctamente." << endl;
}



//CORRUPCION DE POLICIAS
void corromperPolicias(listaPolicia equipo1[4],int &indice1, int &indice2) {
    // Inicializar la semilla para que el azar cambie en cada partida
    srand(static_cast<unsigned int>(time(NULL)));

    // 1. Elegir el primer policía al azar (0 a 3)
    indice1 = rand() % 4;

    // 2. Elegir el segundo policía asegurando que sea diferente al primero
    
    do {
        indice2 = rand() % 4;
    } while (indice1 == indice2);

    // 3. Cambiar el estado a los elegidos
    equipo1[indice1].corrupto = true;
    equipo1[indice2].corrupto = true;

    cout << "-> Shh, han infiltrado 2 agentes corruptos en el equipo." << endl;
    
}



//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    JUEGO     ------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

//FUNCION DADOS
void lanzarDados(int d[4]) {

    bool hayDosDobles=false; //indica si se lanzaron dos dobles
    // Generador de números aleatorios
    static std::mt19937 gen(std::random_device{}() ^ 
                            (static_cast<unsigned int>(std::time(0)) + 
                             static_cast<unsigned int>(std::clock()))); 
    
    std::uniform_int_distribution<> distr(1, 6);

    // 1. Lanzar los 4 dados (usamos el arreglo 'd' que viene por parámetro)
    for(int i = 0; i < 4; i++) {
        d[i] = distr(gen);
    }

    // 2. Arte ASCII de las caras
    std::string caras[7][5] = {
        {"", "", "", "", ""}, 
        {" ----- ", "|     |", "|  o  |", "|     |", " ----- "}, // 1
        {" ----- ", "| o   |", "|     |", "|   o |", " ----- "}, // 2
        {" ----- ", "| o   |", "|  o  |", "|   o |", " ----- "}, // 3
        {" ----- ", "| o o |", "|     |", "| o o |", " ----- "}, // 4
        {" ----- ", "| o o |", "|  o  |", "| o o |", " ----- "}, // 5
        {" ----- ", "| o o |", "| o o |", "| o o |", " ----- "}  // 6
    };

    // 3. Salida visual de los 4 dados en fila
    cout << "\nLanzando los dados..." << endl;
    system("pause");
    for (int i = 0; i < 5; i++) {
        cout << "  " << caras[d[0]][i] << "   " << caras[d[1]][i] 
                  << "   " << caras[d[2]][i] << "   " << caras[d[3]][i] << endl;
    }

   // Fila de identificación de personaje (Alineada: 2 espacios iniciales + 7 del dado + 3 de separación)
    cout << "   Pers. 1     Pers. 2     Pers. 3     Pers. 4" << endl;
    
    // Fila de valores numéricos
    cout << "   Dado: " << d[0] << "     Dado: " << d[1] 
         << "     Dado: " << d[2] << "     Dado: " << d[3] << endl;
}

bool verificarDobles(int d[4]) {
    bool hayDosDobles=false;
    int frecuencias[7] = {0}; // Índices del 0 al 6 (ignoramos el 0)

    // 1. Contar cuántas veces aparece cada cara
    for (int i = 0; i < 4; i++) {
        frecuencias[d[i]]++;
    }

    // 2. Analizar las frecuencias encontradas
    int contadorPares = 0;
    for (int i = 1; i <= 6; i++) {
        if (frecuencias[i] == 2) {
            contadorPares++;
        } 
        else if (frecuencias[i] == 3) {
            contadorPares++; // Un trío cuenta como un par
        } 
        else if (frecuencias[i] == 4) {
            contadorPares = 2; // Un póker son dos pares del mismo número
        }
    }

    if (contadorPares>=2) {
        hayDosDobles=true;
    }
    return hayDosDobles;
}

void mostrarDados(int d[4]) {
    // Arte ASCII de las caras
    std::string caras[7][5] = {
        {"", "", "", "", ""}, 
        {" ----- ", "|     |", "|  o  |", "|     |", " ----- "}, // 1
        {" ----- ", "| o   |", "|     |", "|   o |", " ----- "}, // 2
        {" ----- ", "| o   |", "|  o  |", "|   o |", " ----- "}, // 3
        {" ----- ", "| o o |", "|     |", "| o o |", " ----- "}, // 4
        {" ----- ", "| o o |", "|  o  |", "| o o |", " ----- "}, // 5
        {" ----- ", "| o o |", "| o o |", "| o o |", " ----- "}  // 6
    };

    // Imprimir las caras de los dados fila por fila
    cout << endl;
    for (int i = 0; i < 5; i++) {
        cout << "  " << caras[d[0]][i] << "   " << caras[d[1]][i] 
             << "   " << caras[d[2]][i] << "   " << caras[d[3]][i] << endl;
    }

    // Fila de identificación de personaje (Alineada: 2 espacios iniciales + 7 del dado + 3 de separación)
    cout << "   Pers. 1     Pers. 2     Pers. 3     Pers. 4" << endl;
    
    // Fila de valores numéricos
    cout << "   Dado: " << d[0] << "     Dado: " << d[1] 
         << "     Dado: " << d[2] << "     Dado: " << d[3] << endl;
}

void revelarIdentidad(listaPolicia equipo1[4], listaLadron equipo2[4], int jugador, string turno) {
    if (turno=="policias") {
        int idEstacion= equipo1[jugador].id_estacion;

        for (int i=0; i<4;i++) {
            if (equipo2[i].estado=="Activo") {
                int id = equipo2[i].id_estacion;
                if (id==idEstacion) {
                    cout<<"-> El oficial "<<equipo1[jugador].nombre<<" esta en la misma estacion que el ladron "<<equipo2[i].nombre<<endl;
                    cout<<endl;
                    
                }
            }
        }
    }
    else {
        int idEstacion= equipo2[jugador].id_estacion;
        for (int i=0; i<4;i++) {

            if (equipo1[i].estado=="Activo") {
                int id = equipo1[i].id_estacion;
                if (id==idEstacion) {
                    cout<<"-> El ladron "<<equipo2[jugador].nombre<<" esta en la misma estacion que el policia "<<equipo1[i].nombre<<endl;
                }
            }
        }
    }
}


void recogerLingotes(listaPolicia equipo1[4], listaLadron equipo2[4], int jugador, string turno, listaEstaciones* cabezaEstaciones) {
    // 1. Puntero auxiliar para recorrer la lista de estaciones
    listaEstaciones* auxE = cabezaEstaciones;
    

    
    int idEstacion;
    if (turno=="policias") {
        idEstacion= equipo1[jugador].id_estacion;
    }
    else {
        idEstacion= equipo2[jugador].id_estacion;
    }

    while (auxE != NULL) {

        if (auxE->id == idEstacion) {
            
            if (auxE->lingotes > 0) {
                int cantidad = auxE->lingotes;
                auxE->lingotes = 0;                // La estación se queda vacía

                if (turno=="policias") {
                    equipo1[jugador].lingotes+=cantidad;
                    
                    cout << "-> El policia " << equipo1[jugador].nombre << " ha recuperado " << cantidad << " lingotes de la estacion " << auxE->nombreEstacion << endl;
                }
                else {
                    equipo2[jugador].lingotes+=cantidad;
                    registrarBitacora("ROBO: " + equipo2[jugador].nombre + " robo " + to_string(cantidad) + " lingotes.");
                    
                    cout << "-> El ladron " << equipo2[jugador].nombre << " ha robado " << cantidad << " lingotes de la estacion " << auxE->nombreEstacion << endl;
                }
                
            } else {
                cout << "-> No hay lingotes en la estacion " << auxE->nombreEstacion << endl;
            }
            break; // Detenemos la búsqueda porque ya encontramos la estación
        }
        auxE = auxE->sig;
    }
}

void accionInvestigar(int jugador, listaEstaciones* cabezaEstaciones, listaPolicia equipo1[4], listaLadron equipo2[4]) {
    
    int idActual = equipo1[jugador].id_estacion;
    cout << "-> El Oficial " << equipo1[jugador].nombre << " busca pistas..." << endl;
    system("pause");
    

    if (equipo1[jugador].corrupto==true) { //si el policia es corrupto, nunca encontrara pistas
        cout << "-> No se encontraron ni ladrones ni lingotes cerca de la estacion" << endl;
        cout<<endl;
    }

    else {

        // Variables para rastrear al ladron mas cercano
        int ladronCercanoIdx = -1;
        int distLadronMin = 999;
    
        // 1. BUSCAR LADRÓN CERCANO
        for (int i = 0; i < 4; i++) {
            if (equipo2[i].estado == "Activo") {
                int distancia = abs(equipo2[i].id_estacion - idActual);
                if (distancia < distLadronMin) {
                    distLadronMin = distancia;
                    ladronCercanoIdx = i;
                }
            }
        }
    
    
        // 2. LÓGICA DE PRIORIDAD
        // Si hay un ladrón a menos de 3 estaciones, el oficial prioriza esa sombra
        if (ladronCercanoIdx != -1 && distLadronMin <= 3) {
            cout << "-> ¡AVISTAMIENTO! Un informante dice que vio a alguien con la descripcion de " 
                 << equipo2[ladronCercanoIdx].nombre << " cerca de la estacion ID: " 
                 << equipo2[ladronCercanoIdx].id_estacion << endl;
            cout << "-> Esta a solo " << distLadronMin << " estaciones de aqui." << endl;
        } 
        else {
            // Si no hay ladrones cerca, buscamos lingotes (Pistas de botín)
            listaEstaciones* aux = cabezaEstaciones;
            listaEstaciones* estacionConBotin = NULL;
            int distBotinMin = 999;
    
            while (aux != NULL) {
                if (aux->lingotes > 0) {
                    int dist = abs(aux->id - idActual);
                    if (dist < distBotinMin) {
                        distBotinMin = dist;
                        estacionConBotin = aux;
                    }
                }
                aux = aux->sig;
            }
    
            if (estacionConBotin != NULL) {
                cout << "-> Pista: Hay lingotes en la estacion " 
                     << estacionConBotin->nombreEstacion << " (ID: " << estacionConBotin->id << ")." << endl;
            } else {
                cout << "-> No se encontraron ni ladrones ni lingotes cerca de la estacion" << endl;
            }
        }
    }
}




void accionCapturar(listaPolicia equipo1[4], listaLadron equipo2[4], int jugador, int &ladronesRevelados) {
    
        int idEstacion= equipo1[jugador].id_estacion;
        bool hayLadrones=false;

        for (int i=0; i<4;i++) {
            if (equipo2[i].estado=="Activo") {
                int id = equipo2[i].id_estacion;
                if (id==idEstacion) {
                    ladronesRevelados+=1;
                    hayLadrones=true;
                    cout<<"-> El oficial "<<equipo1[jugador].nombre<<" ha capturado al ladron "<<equipo2[i].nombre<<endl;
                    registrarBitacora("ARRESTO: El oficial " + equipo1[jugador].nombre + " capturo a " + equipo2[i].nombre);
                    equipo2[i].estado="Inactivo";
                    int lingotes = equipo2[i].lingotes;
                    equipo2[i].lingotes=0;
                    equipo1[jugador].lingotes+=lingotes;
                    cout<<"-> El oficial "<<equipo1[jugador].nombre<<" ha decomisado "<<lingotes<<" lingotes al ladron "<<equipo2[i].nombre<<endl;
                    cout<<endl;
                    
                }
            }
        }
        if (hayLadrones==false) {
            cout<<"No hay nadie para capturar."<<endl;
            cout<<endl;
        }
}

void accionAcusar(int jugador, listaPolicia equipo1[4], listaLadron equipo2[4],listaEstaciones* estaciones, int &corruptosRevelados) {
    int seleccionado;
    
    cout << "\n--- PROTOCOLO DE ASUNTOS INTERNOS ---" << endl;
    cout << "Oficial " << equipo1[jugador].nombre << ", ¿a quien desea acusar de corrupcion?" << endl;
    cout<<"! Precaucion: Si falla, sera eliminado del equipo.";
    cout<<endl;
    
    mostrarEquipo(equipo1,equipo2,"policias",estaciones);
    
    cout << "Seleccione el numero del oficial: ";
    cin >> seleccionado;

    int acusadoIdx = seleccionado - 1;

    
    cout << "\nInvestigando pruebas..." << endl;
    system("pause");
    cout<<endl;

    if (equipo1[acusadoIdx].corrupto == true) {
        // ÉXITO: El acusado era corrupto
        cout << "¡JUSTICIA! Se encontro desviacion de pistas. El oficial " 
             << equipo1[acusadoIdx].nombre << " ha sido arrestado." << endl;
        equipo1[acusadoIdx].estado = "Inactivo";
        corruptosRevelados++;
    } 
    else {
        // FALLO: El acusado era inocente, el acusador es eliminado por calumnia
        cout << "¡ERROR GRAVE! El oficial " << equipo1[acusadoIdx].nombre 
             << " es completamente honesto." << endl;
        cout << "El oficial " << equipo1[jugador].nombre 
             << " ha sido destituido por levantar falsos testimonios." << endl;
        equipo1[jugador].estado = "Inactivo";
    }
}


void accionRastrear(int jugador,listaLadron equipo2[4],listaEstaciones* cabezaEstaciones) {
    int idActual=equipo2[jugador].id_estacion;
    listaEstaciones* aux = cabezaEstaciones;
    listaEstaciones* estacionConBotin = NULL;
    int distBotinMin = 999;

    while (aux != NULL) {
        if (aux->lingotes > 0) {
            int dist = abs(aux->id - idActual);
            if (dist < distBotinMin) {
                distBotinMin = dist;
                estacionConBotin = aux;
            }
        }
        aux = aux->sig;
    }

    if (estacionConBotin != NULL) {
        cout << "-> Pista: Hay lingotes en la estacion " 
                << estacionConBotin->nombreEstacion << " (ID: " << estacionConBotin->id << ")." << endl;
    } else {
        cout << "-> No se encontraron lingotes cerca de la estacion" << endl;
    }
}

void accionEsconder(int jugador, listaEstaciones* estaciones, listaLadron equipo2[4]) {

    int idActual = equipo2[jugador].id_estacion;
    listaEstaciones* aux = estaciones;

    while (aux != NULL) {
        if (aux->id == idActual) {
            // Transferencia de botín: del ladrón a la estación
            int cantidadAEsconder = equipo2[jugador].lingotes;
            aux->lingotes += cantidadAEsconder;
            equipo2[jugador].lingotes = 0; // El ladrón queda limpio

            cout << "\n " << equipo2[jugador].nombre << " ha escondido " 
                 << cantidadAEsconder << " lingotes en la estacion " << aux->nombreEstacion << "." << endl;
            cout << "-> El botin esta a salvo en caso de capturas, pero ahora cualquiera puede encontrarlo..." << endl;
            return;
        }
        aux = aux->sig;
    }
}



void accionUsarImplemento(int jugador, string turno, listaPolicia equipo1[4], listaLadron equipo2[4]) {
    int op;
    if (turno=="policias") {
        mostrarMochilaJugador(equipo1,equipo2,turno,jugador);
        cout<<"Seleccione un implemento: ";
        cin>>op;
        op--;
        cout<<"-> Se uso el implemento "<<equipo1[jugador].mochila[op].nombre<<endl;
        int usos= equipo1[jugador].mochila[op].usos_restantes;
        equipo1[jugador].mochila[op].usos_restantes= usos-1;
    }
    else {
        mostrarMochilaJugador(equipo1,equipo2,turno,jugador);
        cout<<"Seleccione un implemento: ";
        cin>>op;
        op--;
        cout<<"-> Se uso el implemento "<<equipo2[jugador].mochila[op].nombre<<endl;
        int usos= equipo2[jugador].mochila[op].usos_restantes;
        equipo2[jugador].mochila[op].usos_restantes= usos-1;
    }
}



void accionPrincipal(listaPolicia equipo1[4],listaLadron equipo2[4], string turno, listaEstaciones* estaciones,int jugador, int &ladronesRevelados, int &corruptosRevelados) {
    string opcion;
    if (turno=="policias") {
        cout<<"a. Investigar    b. Capturar Ladron    c. Acusar Corrupto    d. Usar un implemento"<<endl;
        cout<<"Seleccione una accion principal: ";
        cin>>opcion;

        if (opcion=="a") {
            accionInvestigar(jugador,estaciones,equipo1,equipo2);
        }
        else if (opcion=="b") {
            accionCapturar(equipo1,equipo2,jugador,ladronesRevelados);
        }
        else if (opcion=="c") {
            accionAcusar(jugador,equipo1,equipo2,estaciones,corruptosRevelados);

        }
        else if (opcion=="d") {
            accionUsarImplemento(jugador,turno,equipo1,equipo2);
        }
        else {
            cout<<"! Selecciona una opcion dentro del menu"<<endl;
            cout<<endl;
        }
    }
    else {
        cout<<"a. Rastrear    b. Esconder    c. Usar un implemento"<<endl;
        cout<<"Seleccione una accion principal: ";
        cin>>opcion;

        if (opcion=="a") {
            accionRastrear(jugador,equipo2,estaciones);
        }
        else if (opcion=="b") {
            accionEsconder(jugador,estaciones,equipo2);
        }
        else if (opcion=="c") {
           accionUsarImplemento(jugador,turno,equipo1,equipo2);

        }
        else {
            cout<<"! Selecciona una opcion dentro del menu"<<endl;
            cout<<endl;
        }
    }
}

void moverJugador(listaPolicia equipo1[4],listaLadron equipo2[4], string turno, int jugador, int d[4], listaEstaciones* estaciones) {
    
    int numeroEstaciones = contarEstaciones(estaciones);
    if (turno=="policias") {
        cout<<"-> Moviendo a "<<equipo1[jugador].nombre<<" "<<d[jugador]<<" estaciones..."<<endl;
        system("pause");

        int movimiento= equipo1[jugador].id_estacion + d[jugador];
        if (movimiento>numeroEstaciones) { //si solo hay 20 estaciones pero los dados le piden moverse a la 29
            movimiento=movimiento-numeroEstaciones;
            equipo1[jugador].id_estacion=movimiento;

        }
        else {
            equipo1[jugador].id_estacion=movimiento;

            string msg = "El policia " + equipo1[jugador].nombre + " se movio a la estacion " + obtenerNombreEstacion(movimiento, estaciones);
            registrarBitacora(msg);
        }
        string nombreEstacion = obtenerNombreEstacion(movimiento,estaciones);
        cout<<"-> El policia "<<equipo1[jugador].nombre<<" ahora esta en la estacion "<<nombreEstacion<<endl;
    }
    else {
        cout<<"-> Moviendo a "<<equipo2[jugador].nombre<<" "<<d[jugador]<<" estaciones..."<<endl;
        system("pause");

        int movimiento= equipo2[jugador].id_estacion + d[jugador];
        if (movimiento>numeroEstaciones) { //si solo hay 20 estaciones pero los dados le piden moverse a la 29
            movimiento=movimiento-numeroEstaciones;
            equipo2[jugador].id_estacion=movimiento;

        }
        else {
            equipo2[jugador].id_estacion=movimiento;
        }
        string nombreEstacion = obtenerNombreEstacion(movimiento,estaciones);
        cout<<"-> El ladron "<<equipo2[jugador].nombre<<" ahora esta en la estacion "<<nombreEstacion<<endl;
    }

    //Acciones automaticas
    recogerLingotes(equipo1,equipo2,jugador,turno,estaciones);
    cout<<endl;
    revelarIdentidad(equipo1,equipo2,jugador,turno);
}



void jugarConPersonaje(listaPolicia equipo1[4], listaLadron equipo2[4], string &turno, int &corruptosRevelados, int &ladronesRevelados, listaEstaciones* estaciones, int d[4]) {
    int seleccion=0;
    int jugador;
    bool dobles;

    // Control de acciones: [0] Moverse, [1] Accion Especial
    bool usoMoverse[4] = {false, false,false,false}; //indica si cada integrante del equipo se ha movido en esta ronda o no
    bool usoAccionPrincipal[4] = {false, false,false,false}; //indica si cada integrante del equipo ha usado accion principal o no
    
    int tiempoEnTurno=0;
        while (seleccion!=5) {
            cout<<endl;
            
            if (tiempoEnTurno>0) {
                mostrarDados(d);

            }
            tiempoEnTurno++;
            

            //SELECCION DE PERSONAJES DISPONIBLES
            mostrarEquipo(equipo1,equipo2,turno,estaciones);
            cout<<endl;
            cout << "\nSeleccione el personaje con el que quiere jugar (1-4) o marque 5 para pasar su turno al otro jugador: "; //uno pasa el turno cuando ya no quiere realizar mas nada con sus personajes
            cin >> seleccion;
            jugador=seleccion-1; //para ordenar en el indice de los arreglos
            
            //Si decidio pasar el turno
            //al marcar 5, se sale del while y se pasa el turno
            if(seleccion==5) {
                dobles=verificarDobles(d);
    
                if (turno=="policias") {
                    if (dobles==true) {
                        turno="policias"; //continuas jugando como policia
                        cout<<"! Dos dobles. Vuelves a tirar"<<endl;
                        system("pause");
                        system("cls");
                        cout<<endl;
                    }
                    else {
                        turno="ladrones"; //se pasa el turno
                        cout<<"Pasando turno..."<<endl;
                        system("pause");
                        system("cls");
                    }
                }
                else {
                    if (dobles==true) {
                        turno="ladrones"; //continuas jugando como ladron
                        cout<<"! Dos dobles. Vuelves a tirar"<<endl;
                        system("pause");
                        system("cls");
                        cout<<endl;
                    }
                    else {
                        turno="policias"; //se pasa el turno
                        cout<<"Pasando turno..."<<endl;
                        system("pause");
                        system("cls");
                    }
                }
            }
            else {

                cout<<endl;
                cout << "\n--- Seleccionaste al jugador " << seleccion<< " ---" << endl;
                
                //ACCIONES DE PERSONAJE
                cout<<"----ACCIONES DE PERSONAJE---"<<endl;
                if (!usoMoverse[jugador]) cout << "1. Moverse" <<endl;
                if (!usoAccionPrincipal[jugador]) cout << "2. Ejecutar accion Principal " << endl;
    
                cout << "3. Escoger otro personaje" << endl;
                
                int op;
                cout << "Seleccione una accion: ";
                cin >> op;
        
                if (op == 1 ) { //Eligio moverse 
                    usoMoverse[jugador]=true;
                    moverJugador(equipo1,equipo2,turno,jugador,d,estaciones);
                } 
                else if (op == 2) { //Eligio accion principal
                    usoAccionPrincipal[jugador]=true;
                    accionPrincipal(equipo1,equipo2,turno,estaciones,jugador,ladronesRevelados,corruptosRevelados);
    
                } 
                else if (op == 3) {
                    cout<<"Regresando a seleccion de personajes...";
                    system("pause");
                    cout<<endl;
                   
                }
                else {
                    cout << "[!] Opcion no valida o ya realizada. Intente de nuevo." << endl;
                    system("cls");
                    cout<<endl;
                }
            }
            
            }
}



//FUNCION ESTADISTICAS
void verificarBotin(listaPolicia equipo1[4],listaLadron equipo2[4],int &botinRobado,int &botinRecuperado){
    int lingotes;
    botinRobado = 0;
    botinRecuperado = 0;
    for (int i=0;i<4;i++) {
        lingotes=equipo2[i].lingotes;
        botinRobado+=lingotes;
    }
    for (int i=0;i<4;i++) {
        int lingotes=equipo1[i].lingotes;
        botinRecuperado+=lingotes;
    }
}

void verificarVictoria(int &botin,int &botinRobado,int &botinRecuperado, int &corruptosRevelados, int &ladronesRevelados,bool &condicion1, bool &condicion2, bool &condicion3) {
    if ((ladronesRevelados>=3)&&(botinRecuperado>=(botin*0.9)) || (ladronesRevelados==4) || (corruptosRevelados==2)) {
        condicion1=true; //ganan los policias honestos
        
        if ((corruptosRevelados<2)&&(botinRobado>=(botin*0.4))&&(botinRobado<=(botin*0.6))) {
            condicion3=true; //ganan los policias corruptos
            condicion1=false;
        }
    }

    if ((botinRobado>=(botin*0.7))) {
        condicion2=true; //ganan los ladrones
    }

}

void mostrarEstadisticas(int &botinInicial, int &botinRobado, int &botinRecuperado, int &corruptosRevelados, int &ladronesRevelados) {
    // Calculamos porcentajes rápidos
    float pRobado = ((float)botinRobado / botinInicial) * 100;
    float pRecuperado = ((float)botinRecuperado / botinInicial) * 100;

    cout << "\n========================================================" << endl;
    cout << "                     ESTADISTICAS ACTUALES              " << endl;
    cout << "========================================================" << endl;

    // Fila 1: Progreso del Botín
    cout << " ORO ROBADO: " << botinRobado << " [" << pRobado << "%]      |  ";
    cout << " ORO RECUPERADO: " << botinRecuperado << " [" << pRecuperado << "%]" << endl;

    // Fila 2: Objetivos de Campo
    cout << " LADRONES CAPTURADOS: " << ladronesRevelados << "/4         |  ";
    cout << " CORRUPTOS EXPUESTOS: " << corruptosRevelados << "/2" << endl;

    cout<<endl;
}


//FUNCION TURNO
void Turno(string &turno, int botinInicial, int &botinRobado, int &botinRecuperado, int &corruptosRevelados, int &ladronesRevelados, int d[4], bool &condicion1, bool &condicion2, bool &condicion3,
           listaPolicia equipo1[4], listaLadron equipo2[4], listaEstaciones* estaciones,int turnosLadrones,int i1,int i2) {
    

    if ((turnosLadrones==1)&&(turno=="ladrones")) { //si es el primer turno de los ladrones, se les revela quienes son los corruptos
        cout<<"! Los policias corruptos del equipo 1 son "<<equipo1[i1].nombre<<" y "<<equipo1[i2].nombre<<endl;
        cout<<endl;
    }

    lanzarDados(d);
    jugarConPersonaje(equipo1, equipo2, turno, corruptosRevelados, ladronesRevelados, estaciones, d);
    verificarBotin(equipo1,equipo2,botinRobado,botinRecuperado);
    verificarVictoria(botinInicial,botinRobado,botinRecuperado,corruptosRevelados,ladronesRevelados,condicion1,condicion2,condicion3);
}


//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    MAIN    --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

int main() {
    //INICIALES
    listaPolicia* cabezaPolicia = NULL;
    listaLadron* cabezaLadron = NULL;
    listaImplemento* cabezaImplemento = NULL;
    listaEstaciones* cabezaEstacion = NULL;
    listaPolicia equipo1[4]= {}; //se almacena el equipo de policias que elija el pplayer 1
    listaLadron equipo2[4]= {}; //se almacena el equipo de ladrones que elija el player 2
    int botin=0; //cantidad de lingotes que se van a distribuir
    int indiceCorrupto1; //el numero del jugador del equipo del player 1 que sera corrupto
    int indiceCorrupto2; //el numero del jugador del equipo del player 2 que sera corrupto
    int botinRobado=0;
    int botinRecuperado=0;
    int ladronesRevelados=0;
    int corruptosRevelados=0;
    int dados[4]={};
    reiniciarBitacora();

    bool repetir = true;

    while (repetir) {
        system("cls");

        cout << R"(
       e@@@@@@@@@@@@@@@
      @@@"""""""""""
     @___ ___________
     II__[w] | [i] [z] |
     {======|_|~~~~~~~~~|
    /oO--000''`-OO---OO-'
    )" << endl;
        
        cout << "BIENVENIDO AL TREN DEL ORO" << endl;
        cout << "1. Jugar" << endl;
        cout << "2. Crear" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Modificar" << endl;
        cout << "5. Borrar" << endl;
        cout << "6. Cargar archivo" << endl;
        cout << "7. Salir" << endl;
        
        cout << "Opcion: ";
        string opcion; 
        cin >> opcion;

        if (opcion == "1") {
            if ((cabezaPolicia==NULL) || (cabezaLadron==NULL) || (cabezaImplemento==NULL) || (cabezaEstacion==NULL) ) {
                cout<<"! No puedes jugar sin personajes, implementos, y estaciones. Asegurate de haber creado al o cargado todo desde el archivo! "<<endl;
                cout<<endl;
                system("pause");
            }
            else {
                system("cls");
                //Formacion de Equipos
                cout << "\n========================================================" << endl;
                cout << "                JUGADOR 1 - FUERZA POLICIAL              " << endl;
                cout << "========================================================" << endl;
                formarEquipoPolicias(cabezaEstacion,cabezaImplemento,cabezaPolicia,equipo1,equipo2);
                cout << "\n========================================================" << endl;
                cout << "                JUGADOR 2 - LAS SOMBRAS             " << endl;
                cout << "========================================================" << endl;
                formarEquipoLadrones(cabezaEstacion,cabezaImplemento,cabezaLadron,equipo1,equipo2);

                //Selecciones automaticas antes de jugar
                cout << "\n========================================================" << endl;
                cout << "                  ANTES DE EMPEZAR                       " << endl;
                cout << "========================================================" << endl;
                distribuirBotin(cabezaEstacion,botin);
                cout<<endl;
                corromperPolicias(equipo1,indiceCorrupto1,indiceCorrupto2);
                cout<<endl;
                cout<<" Que empiece el juego! "<<endl;
                system("pause");
                system("cls");

            
                //Juego
                cout<<endl;
                string turno="policias"; //comienza el jugador 1
                bool condicion1=false; //ganaron los ladrones
                bool condicion2=false; //ganaron los policias honestos
                bool condicion3=false; //ganaron los policias corruptos

                int turnosladrones=0;
                int turnospolicias=0;
                
                while  ((condicion1==false)&&(condicion2==false)&&(condicion3==false)) {
                    mostrarEstadisticas(botin, botinRobado, botinRecuperado,corruptosRevelados,ladronesRevelados);
                    system("pause");
                    system("cls");
                    if (turno=="policias") {
                        cout << "\n========================================================" << endl;
                        cout << "                JUGADOR 1 - FUERZA POLICIAL              " << endl;
                        cout << "========================================================" << endl;
                        cout<<endl;
                        turnospolicias++;
                    }
                    else {
                        cout << "\n========================================================" << endl;
                        cout << "                 JUGADOR 2 - LAS SOMBRAS              " << endl;
                        cout << "========================================================" << endl;
                        cout<<endl;
                        turnosladrones++;
                    }
                    
                    Turno(turno, botin, botinRobado, botinRecuperado,corruptosRevelados,ladronesRevelados, dados,condicion1,condicion2,condicion3,
                    equipo1, equipo2, cabezaEstacion,turnosladrones,indiceCorrupto1,indiceCorrupto2);
                    system("cls");
                }

                mostrarEstadisticas( botin, botinRobado, botinRecuperado,corruptosRevelados,ladronesRevelados);
                cout<<endl;
                if (condicion1==true) {
                    cout << "\n========================================================" << endl;
                    cout << "               VICTORIA DE LOS POLICIAS HONESTOS              " << endl;
                    cout << "========================================================" << endl;
                    cout<<endl;
                    system("pause");
                    cout<<"Gracias por jugar!"<<endl; 
                    repetir=false;
                }
                else if (condicion2==true) {
                    cout << "\n========================================================" << endl;
                    cout << "               VICTORIA DE LAS SOMBRAS             " << endl;
                    cout << "========================================================" << endl;
                    cout<<endl;
                    system("pause");
                    cout<<"Gracias por jugar!"<<endl; 
                    repetir=false;
                }
                else {
                    cout << "\n========================================================" << endl;
                    cout << "               VICTORIA DE LOS POLICIAS CORRUPTOS             " << endl;
                    cout << "========================================================" << endl;
                    cout<<endl;
                    system("pause");
                    cout<<"Gracias por jugar!"<<endl; 
                    repetir=false;
                }

            }

            
        }
        else if (opcion == "2") {
            cout<<endl;
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; 
            cin >> op;

            if (op == "a") crearPolicia(cabezaPolicia);
            else if (op == "b") crearLadron(cabezaLadron);
            else if (op == "c") crearImplemento(cabezaImplemento);
            else if (op == "d") crearEstacion(cabezaEstacion);
            else cout << "! Invalido." << endl;
            system("pause");

        }
        else if (opcion == "3") {
            cout<<endl;
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; 
            cin >> op;

            if (op == "a") mostrarPolicias(cabezaPolicia);
            else if (op == "b") mostrarLadrones(cabezaLadron);
            else if (op == "c") mostrarImplementos(cabezaImplemento);
            else if (op == "d") mostrarEstaciones(cabezaEstacion);
            system("pause");

        }
        else if (opcion == "4") {
            cout<<endl;
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; 
            cin >> op;
            
            if (op == "a") modificarPolicia(cabezaPolicia);
            else if (op == "b") modificarLadron(cabezaLadron);
            else if (op == "c") modificarImplemento(cabezaImplemento);
            else if (op == "d") modificarEstacion(cabezaEstacion);
            system("pause");

        }
        else if (opcion == "5") {
            cout<<endl;
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; 
            cin >> op;

            if (op == "a") borrarPolicia(cabezaPolicia);
            else if (op == "b") borrarLadron(cabezaLadron);
            else if (op == "c") borrarImplemento(cabezaImplemento);
            else if (op == "d") borrarEstacion(cabezaEstacion);
            system("pause");

        }
    
        else if (opcion == "6") {
            cout<<endl;
            cout << "Cargando..." << endl;
            cargarMapa(cabezaEstacion);
            cargarAccesorios(cabezaImplemento);
            cargarPersonajes(cabezaPolicia,cabezaLadron);
            system("pause");


        }
        else if (opcion == "7") {
            cout<<endl;
            repetir = false;
            cout << "Adios!" << endl;
        }
        else {
            cout<<endl;
            cout << "! Opcion incorrecta." << endl;
            system("pause");
        }

    }

    return 0;
}