//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    LIBRERIAS  --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

#include <iostream>
#include <string>
#include <cctype> // Para minusculas y isdigit
#include <limits> // Para limpiar el buffer
#include <fstream> // Para archivos
#include <cstdlib> // Para atoi 
#include <random> // Para los dados
#include <ctime>
#include <vector> // <--- AGREGADO: NECESARIO PARA EL GRAFO (CONEXIONES)

using namespace std;

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    ESTRUCTURAS  --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------
struct listaImplemento {
    int id;
    string nombre;
    string tipoPersonaje;
    int durabilidad;
    int usos_restantes;
    bool disponible = true;
    int turnos_cooldown = 0; 
    int turnos_disponible = 0;
    string descripcion; 

    listaImplemento* sig = NULL;
};

struct listaPolicia {
    int id;
    string nombre;
    string bando="policia";
    string rango;
    int puntosVida = 100;
    int posicionX = 0;
    int posicionY = 0;
    string estado = "Activo";
    bool corrupto = false;
    int id_estacion;
    listaImplemento mochila [3];
    int lingotes=0;
    int movimientosRestantes = 0; // <--- AGREGADO: PARA CONTROLAR DADOS EN EL TURNO

    listaPolicia* sig = NULL;
};

struct listaLadron {
    int id;
    string nombre;
    string bando="ladron";
    string rango;
    int puntosVida = 100;
    int posicionX = 0;
    int posicionY = 0;
    string estado = "Activo";
    int lingotes = 0;
    int maxCargaDeLingotes = 3;
    int id_estacion=1;
    listaImplemento mochila [3];
    int movimientosRestantes = 0; // <--- AGREGADO: PARA CONTROLAR DADOS EN EL TURNO

    listaLadron* sig = NULL;
};

struct listaEstaciones {
    int id;
    string nombreEstacion;
    int lingotes;
    vector<int> vecinos; // <--- AGREGADO: LISTA DE CONEXIONES (GRAFO)

    listaEstaciones* sig = NULL;
};

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    FUNCIONES GENERALES  -----------------------------------------
//-----------------------------------------------------------------------------------------------------------

string Minusculas(string texto) {
    for (int i = 0; ((i) < (texto.length())); i++) {
        texto[i] = tolower(texto[i]);
    }
    return texto;
}

int extraerNumero(string texto) {
    string numeroStr = "";
    bool numeroEncontrado = false;
    for (int i = 0; i < texto.length(); i++) {
        if (isdigit(texto[i])) {
            numeroStr += texto[i];
            numeroEncontrado = true;
        } 
        else if (numeroEncontrado) {
            break;
        }
    }
    if (numeroStr == "") return 0;
    else return atoi(numeroStr.c_str());
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    MANEJO DE ARCHIVOS   -------------------------------------
//-----------------------------------------------------------------------------------------------------------

void guardarDatos(listaPolicia* policias, listaLadron* ladrones, listaImplemento* implementos, listaEstaciones* estaciones) {
    // 1. GUARDAR PERSONAJES
    ofstream archivoPersonajes("personajes.tren");
    if (archivoPersonajes.is_open()) {
        int total = 0;
        listaPolicia* p = policias; while(p){ total++; p=p->sig; }
        listaLadron* l = ladrones; while(l){ total++; l=l->sig; }
        
        archivoPersonajes << total << endl; 

        listaPolicia* auxP = policias;
        while (auxP != NULL) {
            archivoPersonajes << "---" << endl;
            archivoPersonajes << auxP->id << endl;
            archivoPersonajes << "Policia" << endl; 
            archivoPersonajes << auxP->nombre << endl;
            archivoPersonajes << "-" << endl; 
            auxP = auxP->sig;
        }

        listaLadron* auxL = ladrones;
        while (auxL != NULL) {
            archivoPersonajes << "---" << endl;
            archivoPersonajes << auxL->id << endl;
            archivoPersonajes << "Ladron" << endl;
            archivoPersonajes << auxL->nombre << endl;
            archivoPersonajes << "-" << endl;
            auxL = auxL->sig;
        }
        archivoPersonajes.close();
        cout << "- Archivo personajes.tren guardado." << endl;
    } else { cout << "! Error guardando personajes." << endl; }

    // 2. GUARDAR IMPLEMENTOS
    ofstream archivoAcc("accesorios.tren");
    if (archivoAcc.is_open()) {
        int total = 0;
        listaImplemento* i = implementos; while(i){ total++; i=i->sig; }
        archivoAcc << total << endl;

        listaImplemento* auxI = implementos;
        while (auxI != NULL) {
            archivoAcc << "---" << endl;
            archivoAcc << auxI->id << endl;
            if (auxI->tipoPersonaje == "Policia Honesto" || auxI->tipoPersonaje == "Policia Corrupto") 
                archivoAcc << "Policia" << endl;
            else 
                archivoAcc << "Ladron" << endl;
            
            archivoAcc << auxI->nombre << endl;
            archivoAcc << "Descripcion: " << auxI->descripcion << endl; 
            archivoAcc << "Uso: " << auxI->durabilidad << endl;
            archivoAcc << "Alcance: 0" << endl; 
            auxI = auxI->sig;
        }
        archivoAcc.close();
        cout << "- Archivo accesorios.tren guardado." << endl;
    } else { cout << "! Error guardando accesorios." << endl; }

    // 3. GUARDAR ESTACIONES
    ofstream archivoMap("Mapa (1).tren");
    if (archivoMap.is_open()) {
        int total = 0;
        listaEstaciones* e = estaciones; while(e){ total++; e=e->sig; }
        archivoMap << total << endl;

        listaEstaciones* auxE = estaciones;
        while (auxE != NULL) {
            archivoMap << "---" << endl;
            archivoMap << auxE->id << endl;
            archivoMap << auxE->nombreEstacion << endl;
            archivoMap << "-" << endl; 
            archivoMap << "-" << endl; 
            auxE = auxE->sig;
        }
        archivoMap.close();
        cout << "- Archivo Mapa (1).tren guardado." << endl;
    } else { cout << "! Error guardando mapa." << endl; }
}

void cargarDatos(listaPolicia*& policias, listaLadron*& ladrones, listaImplemento*& implementos, listaEstaciones*& estaciones) {
    string linea, separador;

    // 1. CARGAR PERSONAJES
    ifstream archPer("personajes.tren");
    if (archPer.is_open()) {
        policias = NULL; ladrones = NULL;
        string totalStr; getline(archPer, totalStr); 
        string idStr, tipo, nombre, items;
        
        while (getline(archPer, separador)) {
            if (separador.find("---") != string::npos) {
                getline(archPer, idStr);
                getline(archPer, tipo);
                getline(archPer, nombre);
                getline(archPer, items); 
                
                if (idStr != "" && idStr != "\r") {
                    int id = atoi(idStr.c_str());
                    if (tipo.find("Policia") != string::npos) {
                        listaPolicia* nuevo = new listaPolicia;
                        nuevo->id = id; nuevo->nombre = nombre; nuevo->bando = "Policia Honesto"; nuevo->rango = "Oficial"; nuevo->sig = NULL;
                        if (policias == NULL) policias = nuevo;
                        else { listaPolicia* temp = policias; while(temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
                    } else { 
                        listaLadron* nuevo = new listaLadron;
                        nuevo->id = id; nuevo->nombre = nombre; nuevo->rango = "Miembro"; nuevo->maxCargaDeLingotes = 3; nuevo->sig = NULL;
                        if (ladrones == NULL) ladrones = nuevo;
                        else { listaLadron* temp = ladrones; while(temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
                    }
                }
            }
        }
        archPer.close();
        cout << "- Personajes cargados." << endl;
    } else { cout << "! No se encontro personajes.tren" << endl; }

    // 2. CARGAR MAPA
    ifstream archMap("Mapa (1).tren");
    if (!archMap.is_open()) archMap.open("Mapa.tren");
    if (archMap.is_open()) {
        estaciones = NULL;
        string totalStr; getline(archMap, totalStr);
        string idStr, nombre, desc, conexiones;

        while (getline(archMap, separador)) {
             if (separador.find("---") != string::npos) {
                getline(archMap, idStr);
                while (idStr.length() == 0 || idStr == "\r") { if (!getline(archMap, idStr)) break; }
                getline(archMap, nombre); getline(archMap, desc); getline(archMap, conexiones);

                if (idStr.length() > 0) {
                    listaEstaciones* nuevo = new listaEstaciones;
                    nuevo->id = atoi(idStr.c_str()); nuevo->nombreEstacion = nombre; nuevo->sig = NULL;
                    if (estaciones == NULL) estaciones = nuevo;
                    else { listaEstaciones* temp = estaciones; while(temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
                }
             }
        }
        archMap.close();
        cout << "- Mapa cargado." << endl;
    } else { cout << "! No se encontro Mapa (1).tren o Mapa.tren" << endl; }

    // 3. CARGAR ACCESORIOS
    ifstream archAcc("accesorios.tren");
    if (archAcc.is_open()) {
        implementos = NULL;
        string totalStr; getline(archAcc, totalStr);
        string idStr, tipo, nombre, funcion, uso, alcance;

        while (getline(archAcc, separador)) {
            if (separador.find("---") != string::npos) {
                getline(archAcc, idStr); getline(archAcc, tipo); getline(archAcc, nombre); getline(archAcc, funcion); getline(archAcc, uso); getline(archAcc, alcance);
                if (idStr.length() > 0) {
                    listaImplemento* nuevo = new listaImplemento;
                    nuevo->id = atoi(idStr.c_str()); nuevo->nombre = nombre;
                    if (tipo.find("Policia") != string::npos) nuevo->tipoPersonaje = "Policia Honesto"; else nuevo->tipoPersonaje = "Ladron";
                    nuevo->durabilidad = extraerNumero(uso); nuevo->usos_restantes = nuevo->durabilidad;
                    nuevo->descripcion = funcion + " - " + alcance; nuevo->sig = NULL;
                    if (implementos == NULL) implementos = nuevo;
                    else { listaImplemento* temp = implementos; while(temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
                }
            }
        }
        archAcc.close();
        cout << "- Accesorios cargados." << endl;
    } else { cout << "! No se encontro accesorios.tren" << endl; }
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    POLICIAS   --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existePolicia(listaPolicia* policia, int idPolicia) {
    listaPolicia *puntero = policia;
    while (puntero != NULL) { if (puntero->id == idPolicia) return true; puntero = puntero->sig; }
    return false;
}

void crearPolicia(listaPolicia*&cabezaPolicia) {
    listaPolicia* nuevo = new listaPolicia;
    int idPolicia; bool repetir = true;
    while (repetir) {
        cout << "- Indique el id: " << endl; cin >> idPolicia;
        if (existePolicia(cabezaPolicia, idPolicia)) cout << "! Ya existe ese ID." << endl;
        else { repetir = false; nuevo->id = idPolicia; }
    }
    cout << endl; cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    cout << "- Indique el nombre: " << endl; string nombre; getline(cin, nombre); nuevo->nombre = nombre;
    cout << "- Seleccione el rango (1-6): " << endl;
    string rango; cin >> rango;
    if (rango == "1") nuevo->rango = "Inspector Jefe";
    else if (rango == "2") nuevo->rango = "Perito Forense";
    else if (rango == "3") nuevo->rango = "Oficial de Asalto";
    else if (rango == "4") nuevo->rango = "Analista de Datos";
    else if (rango == "5") nuevo->rango = "Negociador";
    else if (rango == "6") { nuevo->rango = "Policia Corrupto"; nuevo->corrupto = true; }
    else { cout << "! Rango invalido." << endl; delete nuevo; return; }
    nuevo->sig = NULL;
    if (cabezaPolicia == NULL) cabezaPolicia = nuevo;
    else { listaPolicia* temp = cabezaPolicia; while (temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
    cout << "- Policia creado." << endl;
}

void mostrarPolicias(listaPolicia* policia) {
    if (policia == NULL) { cout << "[ No hay policias ]" << endl; return; }
    listaPolicia* mostrar = policia;
    cout << endl << "TODOS LOS POLICIAS:" << endl;
    int cont = 0;
    while (mostrar != NULL) {
        cout << "[ID: " << mostrar->id << " | " << mostrar->nombre << " | " << mostrar->rango << "] ";
        cont++;
        if (cont == 2) { cout << endl; cont = 0; }
        mostrar = mostrar->sig;
    }
    cout << endl;
}

void modificarPolicia(listaPolicia*&policia) {
    if (policia == NULL) { cout << "No hay policias." << endl; return; }
    int id; cout << "- Ingrese ID a modificar: "; cin >> id;
    listaPolicia* buscar = policia;
    while (buscar != NULL && buscar->id != id) buscar = buscar->sig;
    if (buscar != NULL) {
        cout << "Que desea modificar? 1.Nombre 2.Rango 3.Vida 4.Pos" << endl;
        int op; cin >> op;
        if (op == 1) { cout << "- Nuevo nombre: "; cin.ignore(numeric_limits<streamsize>::max(), '\n'); getline(cin, buscar->nombre); }
        else if (op == 2) { 
            cout << "- Seleccione nuevo rango (1-6): "; string rango; cin >> rango;
            buscar->corrupto = false; buscar->bando = "Policia Honesto";
            if (rango == "1") buscar->rango = "Inspector Jefe";
            else if (rango == "6") { buscar->rango = "Policia"; buscar->corrupto = true; buscar->bando = "Policia"; }
        }
        else if (op == 3) { cout << "- Puntos de vida: "; cin >> buscar->puntosVida; cout << "- Estado: "; cin >> buscar->estado; }
        else if (op == 4) { cout << "- X: "; cin >> buscar->posicionX; cout << "- Y: "; cin >> buscar->posicionY; }
        cout << "- Modificacion realizada." << endl;
    } else cout << "! ID no encontrado." << endl;
}

void borrarPolicia(listaPolicia*& cabeza) {
    if (cabeza == NULL) { cout << "No hay policias." << endl; return; }
    int id; cout << "- ID a borrar: "; cin >> id;
    listaPolicia* actual = cabeza; listaPolicia* anterior = NULL;
    while (actual != NULL && actual->id != id) { anterior = actual; actual = actual->sig; }
    if (actual == NULL) { cout << "! ID no encontrado." << endl; return; }
    if (anterior == NULL) cabeza = actual->sig; else anterior->sig = actual->sig;
    delete actual; cout << "- Policia eliminado." << endl;
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    LADRONES   --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existeLadron(listaLadron* ladron, int id) {
    while (ladron != NULL) { if (ladron->id == id) return true; ladron = ladron->sig; } return false;
}

void crearLadron(listaLadron*&cabeza) {
    listaLadron* nuevo = new listaLadron;
    int id; bool repetir = true;
    while (repetir) {
        cout << "- Indique el id: "; cin >> id;
        if (existeLadron(cabeza, id)) cout << "! ID ya existe." << endl;
        else { repetir = false; nuevo->id = id; }
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Nombre: "; getline(cin, nuevo->nombre);
    cout << "- Rango (1-5): "; string r; cin >> r;
    if (r == "1") nuevo->rango = "Cerebro";
    else if (r == "5") nuevo->rango = "Divergente";
    else nuevo->rango = "Miembro";
    nuevo->sig = NULL;
    if (cabeza == NULL) cabeza = nuevo;
    else { listaLadron* temp = cabeza; while (temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
    cout << "- Ladron creado." << endl;
}

void mostrarLadrones(listaLadron* ladron) {
    if (ladron == NULL) { cout << "[ No hay ladrones ]" << endl; return; }
    listaLadron* m = ladron; cout << "TODOS LOS LADRONES:" << endl; int c = 0;
    while (m != NULL) {
        cout << "[ID: " << m->id << " | " << m->nombre << " | " << m->rango << "] ";
        c++; if (c == 2) { cout << endl; c = 0; } m = m->sig;
    }
    cout << endl;
}

void modificarLadron(listaLadron*&ladron) {
    if (ladron == NULL) { cout << "No hay ladrones." << endl; return; }
    int id; cout << "- ID a modificar: "; cin >> id;
    listaLadron* b = ladron; while (b != NULL && b->id != id) b = b->sig;
    if (b != NULL) {
        cout << "1.Nombre 2.Rango 3.Vida 4.Carga: "; int op; cin >> op;
        if (op == 1) { cin.ignore(numeric_limits<streamsize>::max(), '\n'); getline(cin, b->nombre); }
        else if (op == 2) { string r; cin >> r; if (r == "1") b->rango = "Cerebro"; else b->rango = "Miembro"; }
        else if (op == 3) { cin >> b->puntosVida; cin >> b->estado; }
        else if (op == 4) { cin >> b->lingotes; cin >> b->maxCargaDeLingotes; }
        cout << "- Modificado." << endl;
    } else cout << "! No existe." << endl;
}

void borrarLadron(listaLadron*& cabeza) {
    if (cabeza == NULL) return;
    int id; cout << "- ID a borrar: "; cin >> id;
    listaLadron* act = cabeza; listaLadron* ant = NULL;
    while (act != NULL && act->id != id) { ant = act; act = act->sig; }
    if (act == NULL) cout << "! No encontrado." << endl;
    else { if (ant == NULL) cabeza = act->sig; else ant->sig = act->sig; delete act; cout << "- Eliminado." << endl; }
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    IMPLEMENTOS   ----------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existeImplemento(listaImplemento* imp, int id) {
    while (imp != NULL) { if (imp->id == id) return true; imp = imp->sig; } return false;
}

void crearImplemento(listaImplemento*& cabeza) {
    listaImplemento* nuevo = new listaImplemento;
    int id;
    do { cout << "- ID: "; cin >> id; if (!existeImplemento(cabeza, id)) break; cout << "! Ya existe." << endl; } while (true);
    nuevo->id = id;
    cout << "- Tipo (1.Policia / 2.Ladron): "; string t; cin >> t;
    if (t == "1") nuevo->tipoPersonaje = "Policia Honesto"; else nuevo->tipoPersonaje = "Ladron";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Nombre: "; getline(cin, nuevo->nombre);
    cout << "- Durabilidad: "; cin >> nuevo->durabilidad; nuevo->usos_restantes = nuevo->durabilidad;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Descripcion: "; getline(cin, nuevo->descripcion);
    nuevo->sig = NULL;
    if (cabeza == NULL) cabeza = nuevo; else { listaImplemento* temp = cabeza; while (temp->sig != NULL) temp = temp->sig; temp->sig = nuevo; }
    cout << "- Implemento creado." << endl;
}

void mostrarImplementos(listaImplemento* imp) {
    if (imp == NULL) { cout << "[ Vacio ]" << endl; return; }
    listaImplemento* t = imp;
    while (t != NULL) {
        cout << "[ID:" << t->id << " | " << t->nombre << " | " << t->tipoPersonaje << " | Uso:" << t->durabilidad << "]" << endl;
        t = t->sig;
    }
}

void modificarImplemento(listaImplemento*& imp) {
    if (imp == NULL) return;
    int id; cout << "- ID a modificar: "; cin >> id;
    listaImplemento* b = imp; while (b != NULL && b->id != id) b = b->sig;
    if (b != NULL) {
        cout << "1.Nombre 2.Durabilidad 3.Descripcion: "; int op; cin >> op; cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (op == 1) getline(cin, b->nombre); 
        else if (op == 2) { cin >> b->durabilidad; b->usos_restantes = b->durabilidad; }
        else if (op == 3) getline(cin, b->descripcion); 
        cout << "- Modificado." << endl;
    } else cout << "! No encontrado." << endl;
}

void borrarImplemento(listaImplemento*& cabeza) {
    if (cabeza == NULL) return;
    int id; cout << "- ID borrar: "; cin >> id;
    listaImplemento* act = cabeza; listaImplemento* ant = NULL;
    while (act != NULL && act->id != id){ ant = act; act = act->sig; }
    if (act != NULL) { if (ant == NULL) cabeza = act->sig; else ant->sig = act->sig; delete act; cout << "- Borrado." << endl; } 
    else cout << "! No existe." << endl;
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    ESTACIONES    ----------------------------------------------
//-----------------------------------------------------------------------------------------------------------

bool existeEstacion(listaEstaciones* est, int id) {
    while (est != NULL) { if (est->id == id) return true; est = est->sig; } return false;
}

void crearEstacion(listaEstaciones*& cabeza) {
    listaEstaciones* nuevo = new listaEstaciones;
    int id;
    do { cout << "- ID: "; cin >> id; if (!existeEstacion(cabeza, id)) break; cout << "! Existe." << endl; } while (true);
    nuevo->id = id; cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "- Nombre: "; getline(cin, nuevo->nombreEstacion);
    nuevo->sig = NULL;
    if (cabeza == NULL) cabeza = nuevo; else { listaEstaciones* t = cabeza; while (t->sig != NULL) t = t->sig; t->sig = nuevo; }
    cout << "- Estacion creada." << endl;
}

void mostrarEstaciones(listaEstaciones* est) {
    if (est == NULL) { cout << "[ Vacia ]" << endl; return; }
    listaEstaciones* t = est; int c = 0;
    while (t != NULL) {
        cout << "[ID:" << t->id << " " << t->nombreEstacion << "] ";
        c++; if (c == 3) { cout << endl; c = 0; } t = t->sig;
    }
    cout << endl;
}

void modificarEstacion(listaEstaciones*& est) {
    if (est == NULL) return;
    int id; cout << "- ID a modificar: "; cin >> id;
    listaEstaciones* b = est; while (b != NULL && b->id != id) b = b->sig;
    if (b != NULL) {
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "- Nuevo nombre: "; getline(cin, b->nombreEstacion);
        cout << "- Modificado." << endl;
    } else cout << "! No encontrado." << endl;
}

void borrarEstacion(listaEstaciones*& cabeza) {
    if (cabeza == NULL) return;
    int id; cout << "- ID borrar: "; cin >> id;
    listaEstaciones* act = cabeza; listaEstaciones* ant = NULL;
    while (act != NULL && act->id != id) { ant = act; act = act->sig; }
    if (act != NULL) { if (ant == NULL) cabeza = act->sig; else ant->sig = act->sig; delete act; cout << "- Borrada." << endl; } 
    else cout << "! No existe." << endl;
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    JUEGO (FUNCIONES BASE) -----------------------------------
//-----------------------------------------------------------------------------------------------------------

//FUNCION DADOS
void lanzarDados(listaPolicia equipo1[4], listaLadron equipo2[4], int d[4], string turno) {
    // Generador de números aleatorios
    static std::mt19937 gen(std::random_device{}() ^ (static_cast<unsigned int>(std::time(0)))); 
    std::uniform_int_distribution<> distr(1, 6);

    for(int i = 0; i < 4; i++) {
        d[i] = distr(gen);
    }

    // 2. Arte ASCII de las caras
    std::string caras[7][5] = {
        {"", "", "", "", ""}, 
        {" ----- ", "|     |", "|  o  |", "|     |", " ----- "}, // 1
        {" ----- ", "| o   |", "|     |", "|   o |", " ----- "}, // 2
        {" ----- ", "| o   |", "|  o  |", "|   o |", " ----- "}, // 3
        {" ----- ", "| o o |", "|     |", "| o o |", " ----- "}, // 4
        {" ----- ", "| o o |", "|  o  |", "| o o |", " ----- "}, // 5
        {" ----- ", "| o o |", "| o o |", "| o o |", " ----- "}  // 6
    };

    cout << "\nHas lanzado los dados..." << endl;
    for (int i = 0; i < 5; i++) {
        cout << "  " << caras[d[0]][i] << "   " << caras[d[1]][i] << "   " << caras[d[2]][i] << "   " << caras[d[3]][i] << endl;
    }
    cout << "     " << d[0] << "         " << d[1] << "         " << d[2] << "         " << d[3] << endl;

    // --- CORRECCION: Sintaxis de C++ corregida ---
    if (turno=="policias") {
        for (int i=0; i<4; i++) {
            cout<<"-> El policia "<<equipo1[i].nombre<<" puede moverse "<< d[i] << " estaciones."<<endl;
        }
    } else {
        for (int i=0; i<4; i++) {
            cout<<"-> El ladron "<<equipo2[i].nombre<<" puede moverse "<< d[i] << " estaciones."<<endl;
        }
    }
}


//EQUIPAR LA MOCHILA DE AMBOS BANDOS
void equiparMochila(listaImplemento* implementos, listaPolicia equipo1[4], listaLadron equipo2[4], string bandoPersonaje, int n) {
    cout << "\n--- SELECCION DE EQUIPAMIENTO PARA EL INTEGRANTE " << n + 1 << " de " <<bandoPersonaje<< " ---" << endl;
    for (int i = 0; i < 3; i++) {
        mostrarImplementos(implementos);
        bool itemValido = false;
        while (!itemValido) {
            int idBuscado; cout << "\n Implemento [" << i + 1 << "/3] - Ingrese ID (0 saltar): "; cin >> idBuscado;
            if(idBuscado == 0) break;
            listaImplemento* aux = implementos; bool encontrado = false;
            while (aux != NULL) {
                if (aux->id == idBuscado) {
                    encontrado = true;
                    if (Minusculas(aux->tipoPersonaje) == Minusculas(bandoPersonaje) || aux->tipoPersonaje.find("Policia") != string::npos) { // Permisivo
                        if (Minusculas(bandoPersonaje) == "policia") { equipo1[n].mochila[i] = *aux; equipo1[n].mochila[i].sig = NULL; } 
                        else { equipo2[n].mochila[i] = *aux; equipo2[n].mochila[i].sig = NULL; }
                        cout << "-> " << aux->nombre << " equipado con éxito." << endl; itemValido = true;
                    } else { cout << "! Error: Este objeto es para " << aux->tipoPersonaje << "." << endl; }
                    break;
                }
                aux = aux->sig;
            }
            if (!encontrado) cout << "! ID no encontrado." << endl;
        }
    }
}

//ASIGNAR UNA ESTACION ESTRATEGICA A CADA JUGADOR
void asignarEstacion(listaEstaciones* estaciones, listaPolicia equipo1[4], listaLadron equipo2[4], string bandoPersonaje, int n) {
    cout << "\n--- SELECCION DE ESTACION INICIAL PARA INTEGRANTE " <<n+1<<" de "<< Minusculas(bandoPersonaje) << " ---" << endl;
    mostrarEstaciones(estaciones);
    int idEstacion; bool encontrado = false;
    while (!encontrado) {
        cout << "Ingrese el ID de la estacion de salida: "; cin >> idEstacion;
        if (existeEstacion(estaciones, idEstacion)) {
            encontrado = true;
            if (Minusculas(bandoPersonaje) == "policia") equipo1[n].id_estacion = idEstacion;
            else equipo2[n].id_estacion = idEstacion;
            cout << "-> Estacion " << idEstacion << " asignada." << endl;
        } else cout << "! ID no valido." << endl;
    }
}

void mostrarEquipo(listaPolicia equipo1[4],listaLadron equipo2[4],string bando) {
    if (bando=="policias") {
        cout << "\n============================================================================================" << endl;
        cout << "                         ESTADO ACTUAL: EQUIPO DE POLICIAS" << endl;
        cout << "============================================================================================" << endl;
        for (int i = 0; i < 4; i++) {
            cout << " OFICIAL " << (i + 1) << ": [ID: " << equipo1[i].id << " | Nombre: " << equipo1[i].nombre << " | Estacion: " << equipo1[i].id_estacion << "]" << endl;
            cout << "\n--------------------------------------------------------------------------------------------" << endl;
        }
    } else {
         cout << "\n============================================================================================" << endl;
        cout << "                         ESTADO ACTUAL: EQUIPO DE SOMBRAS" << endl;
        cout << "============================================================================================" << endl;
        for (int i = 0; i < 4; i++) {
            cout << " LADRON " << (i + 1) << ": [ID: " << equipo2[i].id << " | Nombre: " << equipo2[i].nombre << " | Estacion: " << equipo2[i].id_estacion << "]" << endl;
            cout << "\n--------------------------------------------------------------------------------------------" << endl;
        }
    }
}

void formarEquipoPolicias(listaEstaciones* estaciones, listaImplemento* implementos, 
                          listaPolicia* cabeza, listaPolicia equipo1[4], listaLadron equipo2[4]) {
    cout << "\n--- FORME SU EQUIPO DE POLICIAS ---" << endl; mostrarPolicias(cabeza); 
    int seleccionados = 0;
    while (seleccionados < 4) {
        int idEleccion; cout << "\nIngrese el ID del oficial " << seleccionados + 1 << ": "; cin >> idEleccion;
        bool yaElegido = false;
        for (int k = 0; k < seleccionados; k++) { if (equipo1[k].id == idEleccion) { yaElegido = true; break; } }
        if (yaElegido) { cout << "! Ya seleccionado." << endl; continue; }

        listaPolicia* aux = cabeza; bool encontrado = false;
        while (aux != NULL) {
            if (aux->id == idEleccion) {
                encontrado = true;
                equipo1[seleccionados] = *aux; equipo1[seleccionados].sig = NULL; 
                cout << "-> " << aux->nombre << " agregado." << endl;
                equiparMochila(implementos, equipo1, equipo2, "policia", seleccionados);
                asignarEstacion(estaciones, equipo1, equipo2, "policia", seleccionados);
                seleccionados++; break;
            }
            aux = aux->sig;
        }
        if (!encontrado) cout << "! ID no encontrado." << endl;
    }
    mostrarEquipo(equipo1,equipo2,"policias");
}

void formarEquipoLadrones(listaEstaciones* estaciones, listaImplemento* implementos, listaLadron* cabeza, listaPolicia equipo1[4],listaLadron equipo2[4]) {
    cout << "\n--- FORME SU EQUIPO DE LADRONES ---" << endl; mostrarLadrones(cabeza); 
    int seleccionados = 0;
    while (seleccionados < 4) {
        int idEleccion; cout << "Ingrese el ID del ladron " << seleccionados + 1 << ": "; cin >> idEleccion;
        bool yaElegido = false;
        for (int k = 0; k < seleccionados; k++) { if (equipo2[k].id == idEleccion) { yaElegido = true; break; } }
        if (yaElegido) { cout << "! Ya seleccionado." << endl; continue; }

        listaLadron* aux = cabeza; bool encontrado = false;
        while (aux != NULL) {
            if (aux->id == idEleccion) {
                equipo2[seleccionados] = *aux; equipo2[seleccionados].sig = NULL; 
                cout << "-> " << aux->nombre << " agregado." << endl;
                encontrado = true;
                equiparMochila(implementos,equipo1,equipo2,"ladron",seleccionados);
                asignarEstacion(estaciones,equipo1,equipo2,"ladron",seleccionados);
                seleccionados++; break;
            }
            aux = aux->sig;
        }
        if (!encontrado) cout << "! ID no encontrado." << endl;
    }
    mostrarEquipo(equipo1,equipo2,"ladrones");
}


//FUNCION BOTIN
void distribuirBotin(listaEstaciones* cabeza,int &totalLingotes) {
    bool repetir=true;
    while(repetir==true) {
        cout<<"Ingrese la cantidad de lingotes (botin) a distribuir: "; cin>>totalLingotes;
        int contadorEstaciones = 0; listaEstaciones* temp = cabeza;
        while (temp != NULL) { contadorEstaciones++; temp->lingotes = 0; temp = temp->sig; }
        if (totalLingotes > (contadorEstaciones * 3)) cout << "! Error: Capacidad insuficiente." << endl;
        else repetir=false;
    }
    srand(static_cast<unsigned int>(time(NULL)));
    int lingotesRestantes = totalLingotes;
    while (lingotesRestantes > 0) {
        listaEstaciones* aux = cabeza;
        while (aux != NULL && lingotesRestantes > 0) {
            if (aux->lingotes < 3) {
                int espacioDisponible = 3 - aux->lingotes;
                int intentoAsignar = rand() % (espacioDisponible + 1);
                if (intentoAsignar > lingotesRestantes) intentoAsignar = lingotesRestantes;
                aux->lingotes += intentoAsignar; lingotesRestantes -= intentoAsignar;
            }
            aux = aux->sig;
        }
    }
    cout << "-> EXITO: Se han distribuido los " << totalLingotes << " lingotes." << endl;
}

//CORRUPCION DE POLICIAS
void corromperPolicias(listaPolicia equipo1[4],int &indice1, int &indice2) {
    srand(static_cast<unsigned int>(time(NULL)));
    indice1 = rand() % 4;
    do { indice2 = rand() % 4; } while (indice1 == indice2);
    equipo1[indice1].corrupto = true; equipo1[indice2].corrupto = true;
    cout << "-> Se han infiltrado 2 agentes corruptos en el equipo." << endl;
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    LOGICA FALTANTE AÑADIDA  ---------------------------------
//-----------------------------------------------------------------------------------------------------------

// 1. CALCULAR DISTANCIA EN EL GRAFO CICULAR
int calcularDistancia(int id1, int id2, listaEstaciones* mapa) {
    if(id1 == id2) return 0;
    vector<int> orden;
    listaEstaciones* aux = mapa;
    if(!aux) return -1;
    do {
        orden.push_back(aux->id);
        aux = aux->sig;
    } while(aux && aux != mapa);
    int n = orden.size();
    if(n < 2) return -1; // No cycle
    int idx1 = -1, idx2 = -1;
    for(int i=0; i<n; i++) {
        if(orden[i] == id1) idx1 = i;
        if(orden[i] == id2) idx2 = i;
    }
    if(idx1 == -1 || idx2 == -1) return -1;
    int dist = abs(idx1 - idx2);
    return min(dist, n - dist);
}

// 2. INICIALIZAR GRAFO (Conectar estaciones si vienen del archivo sin conexiones)
void inicializarGrafo(listaEstaciones* cabeza) {
    if(!cabeza) return;
    listaEstaciones* aux = cabeza;
    while(aux) {
        // Limpiamos vecinos previos para evitar duplicados
        aux->vecinos.clear();
        // Conexión simple lineal: Anterior <-> Actual <-> Siguiente
        if(aux->sig) {
            aux->vecinos.push_back(aux->sig->id); // Ida
            aux->sig->vecinos.push_back(aux->id); // Vuelta
        }
        // Cerrar el ciclo (Tren circular)
        if(!aux->sig && cabeza != aux) {
            aux->vecinos.push_back(cabeza->id);
            cabeza->vecinos.push_back(aux->id);
        }
        aux = aux->sig;
    }
}

listaEstaciones* buscarEstacion(listaEstaciones* cabeza, int id) {
    while(cabeza) {
        if(cabeza->id == id) return cabeza;
        cabeza = cabeza->sig;
    }
    return NULL;
}

// 3. MOVER JUGADOR (Logica Interactiva)
void moverJugadorInteract(int &idActual, int &movimientos, listaEstaciones* mapa) {
    if(movimientos <= 0) {
        cout << "   (Sin movimientos restantes)" << endl;
        return;
    }
    
    listaEstaciones* actual = buscarEstacion(mapa, idActual);
    if(!actual) return;

    cout << "\n   Ubicacion: " << actual->nombreEstacion << " (ID:" << actual->id << ")";
    cout << "\n   Movimientos: " << movimientos;
    cout << "\n   -> Ingrese ID destino (0 para quedarse): ";
    int dest; cin >> dest;
    
    if(dest == 0) return;

    listaEstaciones* destEst = buscarEstacion(mapa, dest);
    if(!destEst) {
        cout << "   ! Estacion no encontrada." << endl;
        return;
    }

    int distancia = calcularDistancia(idActual, dest, mapa);
    if(distancia == -1) {
        cout << "   ! Error calculando distancia." << endl;
        return;
    }

    if(movimientos < distancia) {
        cout << "   ! No tienes suficientes movimientos. Necesitas " << distancia << " para llegar." << endl;
        return;
    }

    idActual = dest;
    movimientos -= distancia;
    cout << "   -> Has viajado a la estacion " << destEst->nombreEstacion << " pasando por " << distancia << " estaciones intermedias." << endl;
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    MAIN    --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

int main() {
    //INICIALES
    listaPolicia* cabezaPolicia = NULL;
    listaLadron* cabezaLadron = NULL;
    listaImplemento* cabezaImplemento = NULL;
    listaEstaciones* cabezaEstacion = NULL;
    listaPolicia equipo1[4]; //se almacena el equipo de policias
    listaLadron equipo2[4]; //se almacena el equipo de ladrones
    int botin=0; 
    int indiceCorrupto1; 
    int indiceCorrupto2; 

    bool repetir = true;

    while (repetir) {

        cout << endl;
        cout << "   e@@@@@@@@@@@@@@@" << endl;
        cout << "  @@@\"\"\"\"\"\"\"\"\"\"\"" << endl;
        cout << " @___ ___________" << endl;
        cout << " II__[w] | [i] [z] |" << endl;
        cout << " {======|_|~~~~~~~~~|" << endl;
        cout << "/oO--000''`-OO---OO-'" << endl;
        cout << endl;
        
        cout << "BIENVENIDO AL TREN DEL ORO" << endl;
        cout << "1. Jugar" << endl;
        cout << "2. Crear" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Modificar" << endl;
        cout << "5. Borrar" << endl;
        cout << "6. Guardar datos" << endl;
        cout << "7. Cargar datos" << endl;
        cout << "8. Salir" << endl;
        
        cout << "Opcion: ";
        string opcion; 
        cin >> opcion;

        if (opcion == "1") {
            if ((cabezaPolicia==NULL) || (cabezaLadron==NULL) || (cabezaImplemento==NULL) || (cabezaEstacion==NULL) ) {
                cout<<"! No puedes jugar sin personajes, implementos, o estaciones. Asegurate de haber creado o cargado todos! "<<endl;
                cout<<endl;
            }
            else {
                // INICIALIZAR GRAFO (Importante para que 'vecinos' no este vacio)
                inicializarGrafo(cabezaEstacion);

                //Se forman los equipos
                cout << "---------------------- JUGADOR 1 - FUERZA POLICIAL ----------------------------------" << endl;
                formarEquipoPolicias(cabezaEstacion,cabezaImplemento,cabezaPolicia,equipo1,equipo2);
                cout<<endl;
                cout << "---------------------- JUGADOR 2 - LAS SOMBRAS ----------------------------------" << endl;
                formarEquipoLadrones(cabezaEstacion,cabezaImplemento,cabezaLadron,equipo1,equipo2);
                cout<<endl;

                //Cosas automaticas antes de jugar
                distribuirBotin(cabezaEstacion,botin);
                cout<<endl;
                corromperPolicias(equipo1,indiceCorrupto1,indiceCorrupto2);
                cout<<endl;

                cout<<" Que empiece el juego! "<<endl;
                cout<<endl;

                // --- BUCLE DE JUEGO AÑADIDO (LO QUE FALTABA) ---
                bool juegoActivo = true;
                int rondas = 0;
                int maxRondas = 10;

                while(juegoActivo && rondas < maxRondas) {
                    rondas++;
                    cout << "\n=== RONDA " << rondas << " ===" << endl;
                    
                    // --- TURNO POLICIAS ---
                    cout << "\n>>> TURNO POLICIAS <<<" << endl;
                    int dados[4];
                    lanzarDados(equipo1, equipo2, dados, "policias");
                    
                    for(int i=0; i<4; i++) {
                        equipo1[i].movimientosRestantes = dados[i];
                        if(equipo1[i].estado == "Activo") {
                            cout << "\nJugando: Oficial " << equipo1[i].nombre << endl;
                            
                            // 1. Intentar arrestar
                            for(int j=0; j<4; j++) {
                                if(equipo2[j].id_estacion == equipo1[i].id_estacion && equipo2[j].estado == "Activo") {
                                    cout << "! Ladron " << equipo2[j].nombre << " avistado. Arrestar? (s/n): ";
                                    char c; cin >> c;
                                    if(c=='s') {
                                        equipo2[j].estado = "Capturado";
                                        // Recuperar lingotes
                                        listaEstaciones* est = buscarEstacion(cabezaEstacion, equipo1[i].id_estacion);
                                        if(est) est->lingotes += equipo2[j].lingotes;
                                        equipo2[j].lingotes = 0;
                                        cout << "-> Ladron capturado y oro recuperado!" << endl;
                                    }
                                }
                            }

                            // 2. Moverse
                            while(equipo1[i].movimientosRestantes > 0) {
                                moverJugadorInteract(equipo1[i].id_estacion, equipo1[i].movimientosRestantes, cabezaEstacion);
                                if(equipo1[i].movimientosRestantes > 0) {
                                    cout << "Seguir moviendo? (s/n): "; char r; cin >> r;
                                    if(r == 'n') break;
                                }
                            }
                        }
                    }

                    // --- TURNO LADRONES ---
                    cout << "\n>>> TURNO LADRONES <<<" << endl;
                    lanzarDados(equipo1, equipo2, dados, "ladrones");
                    
                    for(int i=0; i<4; i++) {
                        equipo2[i].movimientosRestantes = dados[i];
                        if(equipo2[i].estado == "Activo") {
                            cout << "\nJugando: Ladron " << equipo2[i].nombre << endl;
                            listaEstaciones* est = buscarEstacion(cabezaEstacion, equipo2[i].id_estacion);
                            
                            // 1. Robar
                            if(est && est->lingotes > 0 && equipo2[i].lingotes < equipo2[i].maxCargaDeLingotes) {
                                cout << "Hay " << est->lingotes << " lingotes. Robar uno? (s/n): ";
                                char c; cin >> c;
                                if(c=='s') {
                                    est->lingotes--;
                                    equipo2[i].lingotes++;
                                    cout << "-> Lingote robado. Tienes: " << equipo2[i].lingotes << endl;
                                }
                            }

                            // 2. Moverse
                            while(equipo2[i].movimientosRestantes > 0) {
                                moverJugadorInteract(equipo2[i].id_estacion, equipo2[i].movimientosRestantes, cabezaEstacion);
                                if(equipo2[i].movimientosRestantes > 0) {
                                    cout << "Seguir moviendo? (s/n): "; char r; cin >> r;
                                    if(r == 'n') break;
                                }
                            }
                        }
                    }

                    // CHECK VICTORIA
                    int capturados = 0;
                    int oroRobado = 0;
                    for(int i=0; i<4; i++) {
                        if(equipo2[i].estado == "Capturado") capturados++;
                        oroRobado += equipo2[i].lingotes;
                    }
                    
                    if(capturados == 4) {
                        cout << "\n!!! GANA LA POLICIA: TODOS LOS LADRONES CAPTURADOS !!!" << endl;
                        juegoActivo = false;
                    }
                    if(oroRobado >= (botin/2)+1) {
                         cout << "\n!!! GANAN LOS LADRONES: HAN ROBADO LA MAYORIA DEL ORO !!!" << endl;
                         juegoActivo = false;
                    }
                }
            }
        }
        else if (opcion == "2") {
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; cin >> op;
            if (op == "a") crearPolicia(cabezaPolicia);
            else if (op == "b") crearLadron(cabezaLadron);
            else if (op == "c") crearImplemento(cabezaImplemento);
            else if (op == "d") crearEstacion(cabezaEstacion);
            else cout << "! Invalido." << endl;
        }
        else if (opcion == "3") {
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; cin >> op;
            if (op == "a") mostrarPolicias(cabezaPolicia);
            else if (op == "b") mostrarLadrones(cabezaLadron);
            else if (op == "c") mostrarImplementos(cabezaImplemento);
            else if (op == "d") mostrarEstaciones(cabezaEstacion);
        }
        else if (opcion == "4") {
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; cin >> op;
            if (op == "a") modificarPolicia(cabezaPolicia);
            else if (op == "b") modificarLadron(cabezaLadron);
            else if (op == "c") modificarImplemento(cabezaImplemento);
            else if (op == "d") modificarEstacion(cabezaEstacion);
        }
        else if (opcion == "5") {
            string op;
            cout << "a.Policia b.Ladron c.Item d.Estacion: "; cin >> op;
            if (op == "a") borrarPolicia(cabezaPolicia);
            else if (op == "b") borrarLadron(cabezaLadron);
            else if (op == "c") borrarImplemento(cabezaImplemento);
            else if (op == "d") borrarEstacion(cabezaEstacion);
        }
        else if (opcion == "6") {
            cout << "Guardando..." << endl;
            guardarDatos(cabezaPolicia, cabezaLadron, cabezaImplemento, cabezaEstacion);
        }
        else if (opcion == "7") {
            cout << "Cargando (esto borrara datos actuales)..." << endl;
            cargarDatos(cabezaPolicia, cabezaLadron, cabezaImplemento, cabezaEstacion);
        }
        else if (opcion == "8") {
            cout << "¿Guardar antes de salir? (s/n): "; string r; cin >> r;
            if (r == "s" || r == "S") guardarDatos(cabezaPolicia, cabezaLadron, cabezaImplemento, cabezaEstacion);
            repetir = false; cout << "Adios!" << endl;
        }
        else {
            cout << "! Opcion incorrecta." << endl;
        }
    }
    return 0;
}