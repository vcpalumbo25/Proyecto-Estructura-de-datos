//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    LIBRERIAS  --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

#include <iostream>
#include <string>
#include <cctype> // Para isdigit
#include <limits> // Para limpiar el buffer
#include <fstream> // Para archivos
#include <cstdlib> // Para atoi, rand, srand
#include <ctime>   // Para time

using namespace std;

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    VARIABLES GLOBALES  -----------------------------------------
//-----------------------------------------------------------------------------------------------------------

int TOTAL_LINGOTES_JUEGO = 0;
int LINGOTES_ESCAPADOS = 0;
int LINGOTES_RECUPERADOS = 0;
int LADRONES_CAPTURADOS = 0;
int TOTAL_LADRONES_EQUIPO = 4; 
bool JUEGO_TERMINADO = false;

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    ESTRUCTURAS  --------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

struct listaImplemento {
    int id;
    string nombre;
    string tipoPersonaje;
    int durabilidad;
    int usos_restantes;
    bool disponible = true;
    int turnos_cooldown = 0; 
    int turnos_disponible = 0;
    string descripcion; 
    listaImplemento* sig = NULL;
};

struct listaPolicia {
    int id;
    string nombre;
    string bando = "policia";
    string rango;
    int puntosVida = 100;
    int posicionX = 0;
    int posicionY = 0;
    string estado = "Activo"; 
    bool corrupto = false;
    int id_estacion = 0; 
    listaImplemento mochila [3];
    int lingotes = 0;
    listaPolicia* sig = NULL;
};

struct listaLadron {
    int id;
    string nombre;
    string bando = "ladron";
    string rango;
    int puntosVida = 100;
    int posicionX = 0;
    int posicionY = 0;
    string estado = "Activo"; 
    int lingotes = 0;
    int maxCargaDeLingotes = 3; 
    int id_estacion = 0; 
    listaImplemento mochila [3];
    listaLadron* sig = NULL;
};

struct listaEstaciones {
    int id;
    string nombreEstacion;
    int lingotes = 0;
    string conexiones; 
    int posicionX; 
    int posicionY;
    listaEstaciones* sig = NULL;
};

struct listaCivil {
    int id;
    int id_estacion;
    string informacion; 
    listaCivil* sig = NULL;
};

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    FUNCIONES GENERALES  -----------------------------------------
//-----------------------------------------------------------------------------------------------------------

string Minusculas(string texto) {
    for (int i = 0; ((i) < (texto.length())); i++) {
        texto[i] = tolower(texto[i]);
    }
    return texto;
}

int extraerNumero(string texto) {
    string numeroStr = "";
    bool numeroEncontrado = false;
    for (int i = 0; i < texto.length(); i++) {
        if (isdigit(texto[i])) {
            numeroStr += texto[i];
            numeroEncontrado = true;
        } else if (numeroEncontrado) {
            break;
        }
    }
    if (numeroStr == "") return 0;
    return atoi(numeroStr.c_str());
}

void escribirBitacora(string suceso) {
    ofstream archivo("bitacora_juego.txt", ios::app); 
    if (archivo.is_open()) {
        archivo << suceso << endl;
        archivo.close();
    }
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    GENERADOR DE ARCHIVOS DE EMERGENCIA   --------------------
//-----------------------------------------------------------------------------------------------------------
// Esta funcion crea los archivos si no existen. "Truco de estudiante" para que siempre corra.

void verificarYCrearArchivos() {
    ifstream check1("personajes.tren");
    if (!check1.good()) {
        cout << "[AVISO] Creando 'personajes.tren' por defecto..." << endl;
        ofstream f("personajes.tren");
        f << "12\n---\n1\nPolicia\nDiana \"Sombra\" Vega\n3|6\n---\n2\nPolicia\nComisaria Rostova\n11|12\n---\n3\nPolicia\nCabo Rico\n-\n---\n4\nPolicia\nDetective Navarro\n9\n---\n5\nPolicia\nOficial Tytus\n11\n---\n6\nPolicia\nAnalista Chen\n8\n---\n7\nLadron\nSaboteadora Musa\n1\n---\n8\nLadron\nHacker Zero\n7\n---\n9\nLadron\nMulo Hulk\n10\n---\n10\nLadron\nCerebro Volkov\n4\n---\n11\nLadron\nDistractor Loki\n2\n---\n12\nLadron\nCamaleon Jax\n-\n";
        f.close();
    }
    check1.close();

    ifstream check2("Mapa.tren");
    if (!check2.good()) {
        cout << "[AVISO] Creando 'Mapa.tren' por defecto..." << endl;
        ofstream f("Mapa.tren");
        f << "30\n---\n1\nIturbide\n-\n5:3|12:6|29:1|18:4\n---\n2\nDel Sol\n-\n1:5|16:2|27:4|30:1|8:3\n---\n3\nPlaza de Armas\n-\n6:6|10:1|15:3|21:5\n---\n4\nOHiggins\n-\n5:2|13:5|18:3|21:6|22:1\n---\n5\nArtigas\n-\n3:1|7:4|19:6|25:2\n---\n6\nSan Martin\n-\n1:3|11:5|22:1|14:4\n---\n7\nBolivar\n-\n2:6|14:1|28:5|26:2\n---\n8\nRoraima\n-\n5:3|9:6|17:1|11:4\n---\n9\nTorres del Paine\n-\n10:4|24:2|26:6\n---\n10\nAngostura\n-\n12:5|16:3|20:2|3:1\n---\n11\nFormosa\n-\n7:4|15:6|23:2|2:5\n---\n12\nToledo\n-\n8:1|14:3|24:5|17:6\n---\n13\nKomsomolskaya\n-\n4:2|11:6|20:3|29:5\n---\n14\nAbrantes\n-\n3:5|10:4|18:1|28:6\n---\n15\nGrand Central\n-\n6:2|17:5|25:3|23:4\n---\n16\nArts et Metiers\n-\n1:4|13:1|22:6|7:3\n---\n17\nKungstradgarden\n-\n2:3|19:4|27:5|10:2\n---\n18\nMunchner Freiheit\n-\n3:6|15:2|26:1|30:4\n---\n19\nWestfriedhof\n-\n4:5|8:2|16:6|21:1\n---\n20\nBilbao\n-\n7:3|12:4|23:1|29:5\n---\n21\nShanghai\n-\n1:6|9:5|14:2|28:4\n---\n22\nTCentralen\n-\n5:1|17:3|20:5|25:2\n---\n23\nAtocha\n-\n6:4|18:6|29:3|15:1\n---\n24\nLisboa\n-\n10:5|13:1|22:3|30:6\n---\n25\nSingapur\n-\n8:4|11:2|21:6|27:3\n---\n26\nPlaza Venezuela\n-\n7:2|19:3|28:5|12:1\n---\n27\nSolna Centrum\n-\n12:6|15:1|24:4|9:5\n---\n28\nWestminster\n-\n9:3|16:5|23:2|1:4\n---\n29\nAlameda\n-\n2:6|4:1|20:4|27:3|5:5\n---\n30\nAvtovo\n-\n5:4|13:2|19:1|26:5\n---\n";
        f.close();
    }
    check2.close();

    ifstream check3("accesorios.tren");
    if (!check3.good()) {
        cout << "[AVISO] Creando 'accesorios.tren' por defecto..." << endl;
        ofstream f("accesorios.tren");
        f << "12\n---\n1\nLadron\nBomba de Humo\nFuncion: Evasion\nUso: 1\nAlcance: 0\n---\n2\nLadron\nJamelgo\nFuncion: Distraccion\nUso: 1\nAlcance: 2\n---\n3\nPolicia\nPatines\nFuncion: Movilidad\nUso: 3\nAlcance: 1\n---\n4\nLadron\nLlave Maestra\nFuncion: Control\nUso: 3\nAlcance: 0\n---\n5\nLadron\nCable\nFuncion: Control\nUso: 2\nAlcance: 1\n---\n6\nPolicia\nInmovilizador\nFuncion: Control\nUso: 1\nAlcance: 1\n---\n7\nLadron\nSensor Calor\nFuncion: Vigilancia\nUso: 2\nAlcance: 3\n---\n8\nPolicia\nDrone\nFuncion: Vigilancia\nUso: 1\nAlcance: 6\n---\n9\nPolicia\nLinterna UV\nFuncion: Vigilancia\nUso: 3\nAlcance: 0\n---\n10\nLadron\nChaqueta\nFuncion: Defensa\nUso: 2\nAlcance: 0\n---\n11\nPolicia\nEscudo\nFuncion: Defensa\nUso: 2\nAlcance: 0\n---\n12\nPolicia\nEstimulante\nFuncion: Asalto\nUso: 1\nAlcance: 0\n";
        f.close();
    }
    check3.close();
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    MANEJO DE ARCHIVOS   -------------------------------------
//-----------------------------------------------------------------------------------------------------------

void guardarDatos(listaPolicia* policias, listaLadron* ladrones, listaImplemento* implementos, listaEstaciones* estaciones) {
    
    // 1. GUARDAR PERSONAJES
    ofstream archivoPersonajes("personajes.tren");
    if (archivoPersonajes.is_open()) {
        int total = 0;
        listaPolicia* p = policias; while(p){ total++; p=p->sig;}
        listaLadron* l = ladrones; while(l){ total++; l=l->sig;}
        
        archivoPersonajes << total << endl; 

        listaPolicia* auxP = policias;
        while (auxP != NULL) {
            archivoPersonajes << "---" << endl;
            archivoPersonajes << auxP->id << endl;
            archivoPersonajes << "Policia" << endl; 
            archivoPersonajes << auxP->nombre << endl;
            archivoPersonajes << "-" << endl; // Placeholder items
            auxP = auxP->sig;
        }

        listaLadron* auxL = ladrones;
        while (auxL != NULL) {
            archivoPersonajes << "---" << endl;
            archivoPersonajes << auxL->id << endl;
            archivoPersonajes << "Ladron" << endl;
            archivoPersonajes << auxL->nombre << endl;
            archivoPersonajes << "-" << endl;
            auxL = auxL->sig;
        }
        archivoPersonajes.close();
        cout << "[OK] Personajes guardados." << endl;
    } else {
        cout << "[ERROR] No se puede escribir en 'personajes.tren'. Verifica permisos de carpeta." << endl;
    }

    // 2. GUARDAR MAPA
    ofstream archivoMap("Mapa.tren");
    if (archivoMap.is_open()) {
        int total = 0;
        listaEstaciones* e = estaciones; while(e){ total++; e=e->sig;}
        archivoMap << total << endl;

        listaEstaciones* auxE = estaciones;
        while (auxE != NULL) {
            archivoMap << "---" << endl;
            archivoMap << auxE->id << endl;
            archivoMap << auxE->nombreEstacion << endl;
            archivoMap << "-" << endl; 
            if (auxE->conexiones == "") archivoMap << "-" << endl;
            else archivoMap << auxE->conexiones << endl; 
            
            auxE = auxE->sig;
        }
        archivoMap.close();
        cout << "[OK] Mapa guardado." << endl;
    } else {
        cout << "[ERROR] No se puede escribir en 'Mapa.tren'." << endl;
    }

    // 3. GUARDAR ACCESORIOS
    ofstream archivoAcc("accesorios.tren");
    if (archivoAcc.is_open()) {
        int total = 0;
        listaImplemento* i = implementos; while(i){ total++; i=i->sig;}
        archivoAcc << total << endl;

        listaImplemento* auxI = implementos;
        while (auxI != NULL) {
            archivoAcc << "---" << endl;
            archivoAcc << auxI->id << endl;
            if (auxI->tipoPersonaje == "Policia Honesto") archivoAcc << "Policia" << endl;
            else archivoAcc << "Ladron" << endl;
            
            archivoAcc << auxI->nombre << endl;
            archivoAcc << "Funcion: " << auxI->descripcion << endl; 
            archivoAcc << "Uso: " << auxI->durabilidad << endl;
            archivoAcc << "Alcance: 0" << endl; 
            auxI = auxI->sig;
        }
        archivoAcc.close();
        cout << "[OK] Accesorios guardados." << endl;
    } else {
        cout << "[ERROR] No se puede escribir en 'accesorios.tren'." << endl;
    }
}

void cargarDatos(listaPolicia*& policias, listaLadron*& ladrones, listaImplemento*& implementos, listaEstaciones*& estaciones) {
    string linea, separador;
    cout << "\n--- CARGANDO DATOS ---" << endl;

    // 1. CARGAR PERSONAJES
    ifstream archPer("personajes.tren");
    if (archPer.is_open()) {
        policias = NULL; ladrones = NULL;
        string totalStr, idStr, tipo, nombre, items;
        getline(archPer, totalStr); 
        
        while (getline(archPer, separador)) {
            // Buscamos cualquier linea que empiece con '-'
            if (separador.length() > 0 && separador[0] == '-') {
                getline(archPer, idStr); getline(archPer, tipo); getline(archPer, nombre); getline(archPer, items); 
                
                if (idStr != "" && idStr != "\r") {
                    int id = atoi(idStr.c_str()); 
                    bool esPolicia = (tipo[0] == 'P' || tipo[0] == 'p');

                    if (esPolicia) {
                        listaPolicia* nuevo = new listaPolicia;
                        nuevo->id = id; nuevo->nombre = nombre; nuevo->bando = "Policia Honesto"; nuevo->rango = "Oficial"; nuevo->sig = NULL;
                        if (nombre.find("Inspector") != string::npos) nuevo->rango = "Inspector Jefe";
                        if (policias == NULL) policias = nuevo;
                        else { listaPolicia* t = policias; while(t->sig) t=t->sig; t->sig = nuevo; }
                    } 
                    else { 
                        listaLadron* nuevo = new listaLadron;
                        nuevo->id = id; nuevo->nombre = nombre; nuevo->rango = "Miembro"; nuevo->maxCargaDeLingotes = 3; nuevo->sig = NULL;
                        if (nombre.find("Mulo") != string::npos || nombre.find("Peso") != string::npos) {
                            nuevo->rango = "Mulo"; nuevo->maxCargaDeLingotes = 9; 
                        }
                        if (nombre.find("Fantasma") != string::npos) nuevo->rango = "Fantasma";
                        if (ladrones == NULL) ladrones = nuevo;
                        else { listaLadron* t = ladrones; while(t->sig) t=t->sig; t->sig = nuevo; }
                    }
                }
            }
        }
        archPer.close();
        cout << "[OK] Personajes cargados." << endl;
    } else {
        cout << "[FALLO] No se encontro 'personajes.tren'." << endl;
    } 

    // 2. CARGAR MAPA
    ifstream archMap("Mapa.tren");
    // Soporte para archivos con nombre (1) si el usuario los tiene asi
    if (!archMap.is_open()) archMap.open("Mapa (1).tren");

    if (archMap.is_open()) {
        estaciones = NULL;
        string totalStr, idStr, nombre, desc, conexionesLeidas;
        getline(archMap, totalStr);
        while (getline(archMap, separador)) {
             if (separador.length() > 0 && separador[0] == '-') {
                getline(archMap, idStr);
                while (idStr.length() == 0 || idStr == "\r") if (!getline(archMap, idStr)) break;
                getline(archMap, nombre); getline(archMap, desc); getline(archMap, conexionesLeidas); 

                if (idStr.length() > 0) {
                    listaEstaciones* nuevo = new listaEstaciones;
                    nuevo->id = atoi(idStr.c_str()); 
                    nuevo->nombreEstacion = nombre;
                    nuevo->conexiones = conexionesLeidas; 
                    nuevo->lingotes = 0; 
                    nuevo->sig = NULL;

                    if (estaciones == NULL) estaciones = nuevo;
                    else { listaEstaciones* t = estaciones; while(t->sig) t=t->sig; t->sig = nuevo; }
                }
             }
        }
        archMap.close();
        cout << "[OK] Mapa cargado." << endl;
    } else {
        cout << "[FALLO] No se encontro 'Mapa.tren'." << endl;
    } 

    // 3. CARGAR IMPLEMENTOS
    ifstream archAcc("accesorios.tren");
    if (archAcc.is_open()) {
        implementos = NULL;
        string totalStr, idStr, tipo, nombre, funcion, uso, alcance;
        getline(archAcc, totalStr);
        while (getline(archAcc, separador)) {
            if (separador.length() > 0 && separador[0] == '-') {
                getline(archAcc, idStr); getline(archAcc, tipo); getline(archAcc, nombre); getline(archAcc, funcion); getline(archAcc, uso); getline(archAcc, alcance);
                if (idStr.length() > 0) {
                    listaImplemento* nuevo = new listaImplemento;
                    nuevo->id = atoi(idStr.c_str()); nuevo->nombre = nombre;
                    if (tipo[0] == 'P' || tipo[0] == 'p') nuevo->tipoPersonaje = "Policia Honesto"; else nuevo->tipoPersonaje = "Ladron";
                    nuevo->durabilidad = extraerNumero(uso); nuevo->usos_restantes = nuevo->durabilidad; nuevo->descripcion = funcion; nuevo->sig = NULL;
                    if (implementos == NULL) implementos = nuevo;
                    else { listaImplemento* t = implementos; while(t->sig) t=t->sig; t->sig = nuevo; }
                }
            }
        }
        archAcc.close();
        cout << "[OK] Accesorios cargados." << endl;
    } else {
        cout << "[FALLO] No se encontro 'accesorios.tren'." << endl;
    } 
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    AUXILIARES Y LOGICA DE JUEGO  ---------------------------
//-----------------------------------------------------------------------------------------------------------

void generarCiviles(listaCivil*& cabezaCiviles, listaEstaciones* mapa) {
    int numCiviles = rand() % 6 + 5; 
    int maxEst = 0;
    listaEstaciones* t = mapa;
    while(t) { maxEst++; t=t->sig; }

    if (maxEst == 0) return; 

    for(int i=0; i<numCiviles; i++) {
        listaCivil* nuevo = new listaCivil;
        nuevo->id = i + 1;
        nuevo->id_estacion = (rand() % maxEst) + 1; 
        
        int tipoPista = rand() % 3;
        if (tipoPista == 0) nuevo->informacion = "Vi a alguien con una maleta pesada.";
        else if (tipoPista == 1) nuevo->informacion = "Escuche ruidos raros aqui.";
        else nuevo->informacion = "No he visto nada.";

        nuevo->sig = cabezaCiviles;
        cabezaCiviles = nuevo;
    }
    cout << "-> SISTEMA: " << numCiviles << " civiles en el mapa." << endl;
}

void desaparecerCiviles(listaCivil*& cabezaCiviles) {
    if (cabezaCiviles == NULL) return;
    listaCivil* aBorrar = cabezaCiviles;
    cabezaCiviles = cabezaCiviles->sig;
    cout << "-> SISTEMA: Un civil ha salido del metro." << endl;
    delete aBorrar;
}

listaEstaciones* buscarEstacion(listaEstaciones* cabeza, int id) {
    listaEstaciones* temp = cabeza;
    while(temp) {
        if(temp->id == id) return temp;
        temp = temp->sig;
    }
    return NULL;
}

void mostrarPolicias(listaPolicia* p) { while(p) { cout<<"["<<p->id<<" "<<p->nombre<<"] "; p=p->sig; } cout<<endl; }
void mostrarLadrones(listaLadron* l) { while(l) { cout<<"["<<l->id<<" "<<l->nombre<<"] "; l=l->sig; } cout<<endl; }

bool estanConectadas(listaEstaciones* cabezaMapa, int idOrigen, int idDestino) {
    listaEstaciones* origen = buscarEstacion(cabezaMapa, idOrigen);
    if (origen == NULL) return false;
    
    if (origen->conexiones == "" || origen->conexiones == "-") return true; // Fail-safe

    string conex = origen->conexiones;
    string numeroTemp = "";
    for (int i = 0; i < conex.length(); i++) {
        char c = conex[i];
        if (isdigit(c)) numeroTemp += c;
        else if (c == ':') {
            if (numeroTemp != "") {
                int idVecino = atoi(numeroTemp.c_str());
                if (idVecino == idDestino) return true;
            }
            while (i < conex.length() && conex[i] != '|') i++;
            numeroTemp = ""; 
        } else numeroTemp = "";
    }
    return false;
}

void verificarVictoria() {
    float pEscapado = 0.0, pRecuperado = 0.0, pCapturados = 0.0;
    if (TOTAL_LINGOTES_JUEGO > 0) {
        pEscapado = (float)LINGOTES_ESCAPADOS / (float)TOTAL_LINGOTES_JUEGO;
        pRecuperado = (float)LINGOTES_RECUPERADOS / (float)TOTAL_LINGOTES_JUEGO;
    }
    if (TOTAL_LADRONES_EQUIPO > 0) 
        pCapturados = (float)LADRONES_CAPTURADOS / (float)TOTAL_LADRONES_EQUIPO;

    cout << "\n--- MARCADOR ---" << endl;
    cout << "Oro Escapado: " << LINGOTES_ESCAPADOS << "/" << TOTAL_LINGOTES_JUEGO << endl;
    cout << "Oro Recuperado: " << LINGOTES_RECUPERADOS << "/" << TOTAL_LINGOTES_JUEGO << endl;
    cout << "Ladrones Presos: " << LADRONES_CAPTURADOS << "/" << TOTAL_LADRONES_EQUIPO << endl;

    if (pEscapado > 0.70) {
        cout << "\n!!! VICTORIA DE LOS LADRONES !!!" << endl;
        JUEGO_TERMINADO = true;
    }
    else if ((pCapturados >= 0.80 && pRecuperado >= 0.90) || (LADRONES_CAPTURADOS == TOTAL_LADRONES_EQUIPO)) {
        cout << "\n!!! VICTORIA DE LA POLICIA HONESTA !!!" << endl;
        JUEGO_TERMINADO = true;
    }
    else if (LADRONES_CAPTURADOS == TOTAL_LADRONES_EQUIPO && pEscapado >= 0.40 && pEscapado <= 0.60) {
        cout << "\n!!! VICTORIA DE LOS POLICIAS CORRUPTOS !!!" << endl;
        JUEGO_TERMINADO = true;
    }
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    ACCIONES DEL JUEGO  ---------------------------------------
//-----------------------------------------------------------------------------------------------------------

void moverPersonaje(string bando, int indice, listaPolicia policias[], listaLadron ladrones[], listaEstaciones* mapa, int dado) {
    int idActual, idDestino;
    string nombre;

    if (bando == "policia") { idActual = policias[indice].id_estacion; nombre = policias[indice].nombre; } 
    else { idActual = ladrones[indice].id_estacion; nombre = ladrones[indice].nombre; }

    cout << endl << "-> " << nombre << " en estacion " << idActual << ". (Mov: " << dado << ")" << endl;
    cout << "Destino: "; cin >> idDestino;

    if (idActual == idDestino) { cout << "Se queda quieto." << endl; return; }

    if (estanConectadas(mapa, idActual, idDestino)) {
        if (bando == "policia") policias[indice].id_estacion = idDestino;
        else ladrones[indice].id_estacion = idDestino;
        cout << "Movimiento exitoso." << endl;
        escribirBitacora(nombre + " movio a est " + to_string(idDestino));
        
        listaEstaciones* est = buscarEstacion(mapa, idDestino);
        if (est && est->lingotes > 0) {
            if (bando == "ladron") {
                if (ladrones[indice].lingotes < ladrones[indice].maxCargaDeLingotes) {
                    cout << "¡TOMO UN LINGOTE!" << endl;
                    ladrones[indice].lingotes++; est->lingotes--;
                } else cout << "Mochila llena." << endl;
            } else cout << "El policia asegura el area del oro." << endl;
        }
    } else cout << "! No puedes ir ahi (muy lejos o desconectada)." << endl;
}

void usarItem(string bando, int indice, listaPolicia policias[], listaLadron ladrones[], listaEstaciones* mapa) {
    cout << "\n--- MOCHILA ---" << endl;
    for(int i=0; i<3; i++) {
        string nom = (bando=="policia") ? policias[indice].mochila[i].nombre : ladrones[indice].mochila[i].nombre;
        int usos = (bando=="policia") ? policias[indice].mochila[i].usos_restantes : ladrones[indice].mochila[i].usos_restantes;
        if (nom != "" && usos > 0) cout << i+1 << ". " << nom << " (" << usos << ")" << endl;
        else cout << i+1 << ". [Vacio]" << endl;
    }
    cout << "Usar cual? (0 salir): "; int op; cin >> op;
    if (op < 1 || op > 3) return;

    listaImplemento* it = (bando=="policia") ? &policias[indice].mochila[op-1] : &ladrones[indice].mochila[op-1];
    if (it->nombre == "" || it->usos_restantes <= 0) return;

    cout << "Usando " << it->nombre << "..." << endl;
    it->usos_restantes--;
    if (it->usos_restantes == 0) { cout << "Se rompio el item." << endl; it->nombre = ""; }
    escribirBitacora("Item usado.");
}

void realizarAccion(string bando, int indice, listaPolicia policias[], listaLadron ladrones[], listaEstaciones* mapa, listaCivil* cabezaCiviles) {
    cout << "\n--- ACCION ---" << endl;
    if (bando == "policia") {
        cout << "1. Investigar  2. Capturar  3. Interrogar  4. Usar Item" << endl;
    } else {
        cout << "1. Rastrear  2. Escapar  3. Usar Item" << endl;
    }
    int op; cin >> op;
    int idEst = (bando=="policia") ? policias[indice].id_estacion : ladrones[indice].id_estacion;
    listaEstaciones* estActual = buscarEstacion(mapa, idEst);

    if (bando == "policia") {
        if (op == 1) { 
            cout << "Investigando..." << endl;
            if (estActual->lingotes > 0) cout << "HAY " << estActual->lingotes << " LINGOTES." << endl;
            else cout << "Nada." << endl;
        }
        else if (op == 2) { 
            bool cap = false;
            for(int i=0; i<4; i++) {
                if (ladrones[i].id_estacion == idEst && ladrones[i].estado == "Activo") {
                    if (rand()%6+1 >= 3) { 
                        cout << "¡CAPTURADO " << ladrones[i].nombre << "!" << endl;
                        ladrones[i].estado = "Capturado"; LADRONES_CAPTURADOS++;
                        LINGOTES_RECUPERADOS += ladrones[i].lingotes; ladrones[i].lingotes=0;
                        cap = true;
                    } else cout << "Se escapo." << endl;
                }
            }
            if (!cap) cout << "Nadie aqui." << endl;
        }
        else if (op == 3) {
            bool hay = false;
            listaCivil* c = cabezaCiviles;
            while(c) {
                if (c->id_estacion == idEst) { 
                    cout << "Civil dice: " << c->informacion << endl; hay=true; break; 
                } 
                c=c->sig; 
            }
            if (!hay) cout << "No hay civiles." << endl;
        }
        else if (op == 4) usarItem(bando, indice, policias, ladrones, mapa);
    } 
    else { 
        if (op == 1) cout << "Oro en sala: " << estActual->lingotes << endl;
        else if (op == 2) {
            if ((idEst == 1 || idEst == 30) && ladrones[indice].lingotes > 0) {
                cout << "¡DINERO ASEGURADO!" << endl;
                LINGOTES_ESCAPADOS += ladrones[indice].lingotes;
                ladrones[indice].lingotes = 0;
            } else cout << "No puedes escapar aqui o no tienes oro." << endl;
        }
        else if (op == 3) usarItem(bando, indice, policias, ladrones, mapa);
    }
}

//-----------------------------------------------------------------------------------------------------------
//---------------------------------------------    MAIN Y SETUP    -------------------------------------------
//-----------------------------------------------------------------------------------------------------------

void asignarEstacion(listaEstaciones* est, listaPolicia p[], listaLadron l[], string bando, int n) {
    cout << "ID Estacion: ";
    int id; cin >> id;
    if(bando=="policia") p[n].id_estacion=id; else l[n].id_estacion=id;
}

void formarEquipos(listaEstaciones* est, listaImplemento* imp, listaPolicia* cp, listaLadron* cl, listaPolicia ep[], listaLadron el[]) {
    cout << "\n--- FORMANDO POLICIAS ---" << endl;
    mostrarPolicias(cp);
    for(int i=0; i<4; i++) {
        int id; cout << "ID Policia " << i+1 << ": "; cin >> id;
        listaPolicia* aux = cp;
        while(aux) { if(aux->id==id) { ep[i] = *aux; ep[i].sig=NULL; break; } aux=aux->sig; }
        asignarEstacion(est, ep, el, "policia", i);
        // Equipar item basico
        ep[i].mochila[0].id=8; ep[i].mochila[0].nombre="Radio"; ep[i].mochila[0].usos_restantes=2;
    }
    cout << "\n--- FORMANDO LADRONES ---" << endl;
    mostrarLadrones(cl);
    for(int i=0; i<4; i++) {
        int id; cout << "ID Ladron " << i+1 << ": "; cin >> id;
        listaLadron* aux = cl;
        while(aux) { if(aux->id==id) { el[i] = *aux; el[i].sig=NULL; break; } aux=aux->sig; }
        asignarEstacion(est, ep, el, "ladron", i);
        el[i].mochila[0].id=1; el[i].mochila[0].nombre="Ganzua"; el[i].mochila[0].usos_restantes=2;
    }
}

void distribuirBotin(listaEstaciones* cabeza) {
    int total; cout << "Cuantos lingotes repartir? "; cin >> total;
    TOTAL_LINGOTES_JUEGO = total;
    listaEstaciones* t = cabeza;
    while (total > 0 && t) {
        t->lingotes++; total--; t = t->sig;
        if (!t && total>0) t=cabeza;
    }
    cout << "Botin repartido." << endl;
}

void corromperPolicias(listaPolicia p[]) {
    srand(time(0));
    int i1 = rand()%4; int i2 = (i1+1)%4;
    p[i1].corrupto = true; p[i2].corrupto = true;
    cout << "Corruptos elegidos (Secreto)." << endl;
}

int main() {
    // 1. AUTO-GENERAR ARCHIVOS SI FALTAN (SOLUCION AL PROBLEMA DE CARGA)
    verificarYCrearArchivos();

    listaPolicia* cp = NULL;
    listaLadron* cl = NULL;
    listaImplemento* ci = NULL;
    listaEstaciones* ce = NULL;
    listaCivil* cc = NULL;
    
    listaPolicia ep[4];
    listaLadron el[4];
    
    bool repetir = true;
    while (repetir) {
        cout << "\n=== TREN DEL ORO ===" << endl;
        cout << "1. Jugar\n2. Cargar Datos\n3. Guardar Datos\n4. Salir\nOpcion: ";
        string op; cin >> op;

        if (op == "2") cargarDatos(cp, cl, ci, ce);
        else if (op == "3") guardarDatos(cp, cl, ci, ce);
        else if (op == "1") {
            if (!cp || !cl || !ce) { cout << "! Carga datos primero." << endl; continue; }
            
            formarEquipos(ce, ci, cp, cl, ep, el);
            distribuirBotin(ce);
            corromperPolicias(ep);
            generarCiviles(cc, ce);

            int turno = 1;
            JUEGO_TERMINADO = false;

            while (!JUEGO_TERMINADO) {
                cout << "\n\n===== RONDA " << turno << " =====" << endl;
                escribirBitacora("Ronda " + to_string(turno));

                cout << ">>> TURNO POLICIA <<<" << endl;
                cout << "Elige (1-4): "; int pIdx; cin >> pIdx; pIdx--;
                if (ep[pIdx].estado == "Activo") {
                    int dado = rand()%6+1;
                    moverPersonaje("policia", pIdx, ep, el, ce, dado);
                    realizarAccion("policia", pIdx, ep, el, ce, cc);
                } else cout << "Inhabilitado." << endl;
                
                verificarVictoria(); if(JUEGO_TERMINADO) break;

                cout << ">>> TURNO LADRONES <<<" << endl;
                cout << "Elige (1-4): "; int lIdx; cin >> lIdx; lIdx--;
                if (el[lIdx].estado == "Activo") {
                    int dado = rand()%6+1;
                    moverPersonaje("ladron", lIdx, ep, el, ce, dado);
                    if (el[lIdx].rango == "Fantasma") cout << "(Invisible al radar...)" << endl;
                    realizarAccion("ladron", lIdx, ep, el, ce, cc);
                } else cout << "Preso." << endl;

                verificarVictoria(); if(JUEGO_TERMINADO) break;
                
                if (turno % 2 == 0) desaparecerCiviles(cc);
                turno++;
            }
        }
        else if (op == "4") repetir = false;
    }
    return 0;
}